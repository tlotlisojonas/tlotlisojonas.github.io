<?php


 $uct_residences = ['Liesbiek Gardens', 'Clarinus Village', 'College House', 'Dullah Omar Hall', 'Fuller Hall', 'Glenres', 'Graca Machel Hall', 'Kilindini', 'Kopano', 'Leo Marquard Hall', 'Rochester House', 'Smuts Hall', 'Tugwel Hall', 'University House', 'Varietas', 'Groote Schuur', 'Medical Residence', 'Forrest Hill', 'Groote Schuur Flats', 'Baxter Hall', 'woolsack', 'Obz Square' , 'Other'];

$home_centres = ['QWAQWA', 'Umlazi', 'Philippi', 'Katlehong', 'Sekhukhune Rebone', 'Other'];

$society_positions = ['Chairperson', 'Dept-Chairperson', 'Academic Rep', 'Treasurer', 'Secretary', 'Dept-Secretary', 'Communications Rep', 'Events Coordinator'];

$uct_fuculties =['EBE', 'Health Sciences', 'Law', 'Science','Commerce', 'Humanities'];



$mentors = ['Tlotliso Jonas', 'Amanda Ngcobo', 'Mlungisi Khumalo', 'Dumisani Zunguza', 'Livhuwami Mukwevho', 'Evans Tjabadi', 'Lusanda', 'Phiwankosi Msimango', 'Thandeka Mhlambi', 'Noxolo Ngcobo', 'Mendisa Kheshwayo', 'Tshediso Letsoara', 'Yamkela Mlandulwa', 'Alfonso Timbana', 'Kwanele Ndwandwe', 'Reuben Mahlaba', 'Tselani Matuludi', 'Unathi Bodlinwe', 'Oratile','None', 'Other'];

$uct_year = [1, 2, 3, 4, 5, 6, 7, 8, 9 ,10];

$yes_or_no = ['Yes', 'No'];

$gender = ['Male', 'Female'];



$res_count = count($uct_residences);


?>
