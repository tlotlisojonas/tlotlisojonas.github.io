<?php

define("DB_SERVER", "localhost");
define("DB_USER", "root");
define("DB_PASS", "qazwsx123EDCRFV");
define("DB_NAME", "kutlwanong");

?>
