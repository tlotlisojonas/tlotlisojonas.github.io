<?php

  // Subjects

  function find_all_subjects($options=[]) {
    global $db;

    $visible = $options['visible'] ?? false;

    $sql = "SELECT * FROM subjects ";
    if($visible) {
      $sql .= "WHERE visible = true ";
    }
    $sql .= "ORDER BY position ASC";
    //echo $sql;
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    return $result;
  }

  function find_subject_by_id($id, $options=[]) {
    global $db;

    $visible = $options['visible'] ?? false;

    $sql = "SELECT * FROM subjects ";
    $sql .= "WHERE id='" . db_escape($db, $id) . "' ";
    if($visible) {
      $sql .= "AND visible = true";
    }
    // echo $sql;
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    $subject = mysqli_fetch_assoc($result);
    mysqli_free_result($result);
    return $subject; // returns an assoc. array
  }

  function validate_subject($subject) {
    $errors = [];

    // menu_name
    if(is_blank($subject['menu_name'])) {
      $errors[] = "Name cannot be blank.";
    } elseif(!has_length($subject['menu_name'], ['min' => 2, 'max' => 255])) {
      $errors[] = "Name must be between 2 and 255 characters.";
    }

    // position
    // Make sure we are working with an integer
    $postion_int = (int) $subject['position'];
    if($postion_int <= 0) {
      $errors[] = "Position must be greater than zero.";
    }
    if($postion_int > 999) {
      $errors[] = "Position must be less than 999.";
    }

    // visible
    // Make sure we are working with a string
    $visible_str = (string) $subject['visible'];
    if(!has_inclusion_of($visible_str, ["0","1"])) {
      $errors[] = "Visible must be true or false.";
    }

    return $errors;
  }

  function insert_subject($subject) {
    global $db;

    $errors = validate_subject($subject);
    if(!empty($errors)) {
      return $errors;
    }

    shift_subject_positions(0, $subject['position']);

    $sql = "INSERT INTO subjects ";
    $sql .= "(menu_name, position, visible) ";
    $sql .= "VALUES (";
    $sql .= "'" . db_escape($db, $subject['menu_name']) . "',";
    $sql .= "'" . db_escape($db, $subject['position']) . "',";
    $sql .= "'" . db_escape($db, $subject['visible']) . "'";
    $sql .= ")";
    $result = mysqli_query($db, $sql);
    // For INSERT statements, $result is true/false
    if($result) {
      return true;
    } else {
      // INSERT failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }

  function update_subject($subject) {
    global $db;

    $errors = validate_subject($subject);
    if(!empty($errors)) {
      return $errors;
    }

    $old_subject = find_subject_by_id($subject['id']);
    $old_position = $old_subject['position'];
    shift_subject_positions($old_position, $subject['position'], $subject['id']);

    $sql = "UPDATE subjects SET ";
    $sql .= "menu_name='" . db_escape($db, $subject['menu_name']) . "', ";
    $sql .= "position='" . db_escape($db, $subject['position']) . "', ";
    $sql .= "visible='" . db_escape($db, $subject['visible']) . "' ";
    $sql .= "WHERE id='" . db_escape($db, $subject['id']) . "' ";
    $sql .= "LIMIT 1";

    $result = mysqli_query($db, $sql);
    // For UPDATE statements, $result is true/false
    if($result) {
      return true;
    } else {
      // UPDATE failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }

  }

  function delete_subject($id) {
    global $db;

    $old_subject = find_subject_by_id($id);
    $old_position = $old_subject['position'];
    shift_subject_positions($old_position, 0, $id);

    $sql = "DELETE FROM subjects ";
    $sql .= "WHERE id='" . db_escape($db, $id) . "' ";
    $sql .= "LIMIT 1";
    $result = mysqli_query($db, $sql);

    // For DELETE statements, $result is true/false
    if($result) {
      return true;
    } else {
      // DELETE failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }

  function shift_subject_positions($start_pos, $end_pos, $current_id=0) {
    global $db;

    if($start_pos == $end_pos) { return; }

    $sql = "UPDATE subjects ";
    if($start_pos == 0) {
      // new item, +1 to items greater than $end_pos
      $sql .= "SET position = position + 1 ";
      $sql .= "WHERE position >= '" . db_escape($db, $end_pos) . "' ";
    } elseif($end_pos == 0) {
      // delete item, -1 from items greater than $start_pos
      $sql .= "SET position = position - 1 ";
      $sql .= "WHERE position > '" . db_escape($db, $start_pos) . "' ";
    } elseif($start_pos < $end_pos) {
      // move later, -1 from items between (including $end_pos)
      $sql .= "SET position = position - 1 ";
      $sql .= "WHERE position > '" . db_escape($db, $start_pos) . "' ";
      $sql .= "AND position <= '" . db_escape($db, $end_pos) . "' ";
    } elseif($start_pos > $end_pos) {
      // move earlier, +1 to items between (including $end_pos)
      $sql .= "SET position = position + 1 ";
      $sql .= "WHERE position >= '" . db_escape($db, $end_pos) . "' ";
      $sql .= "AND position < '" . db_escape($db, $start_pos) . "' ";
    }
    // Exclude the current_id in the SQL WHERE clause
    $sql .= "AND id != '" . db_escape($db, $current_id) . "' ";

    $result = mysqli_query($db, $sql);
    // For UPDATE statements, $result is true/false
    if($result) {
      return true;
    } else {
      // UPDATE failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }


  // Pages

  function find_all_pages() {
    global $db;

    $sql = "SELECT * FROM pages ";
    $sql .= "ORDER BY subject_id ASC, position ASC";
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    return $result;
  }

  function find_page_by_id($id, $options=[]) {
    global $db;

    $visible = $options['visible'] ?? false;

    $sql = "SELECT * FROM pages ";
    $sql .= "WHERE id='" . db_escape($db, $id) . "' ";
    if($visible) {
      $sql .= "AND visible = true";
    }
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    $page = mysqli_fetch_assoc($result);
    mysqli_free_result($result);
    return $page; // returns an assoc. array
  }

  function validate_page($page) {
    $errors = [];

    // subject_id
    if(is_blank($page['subject_id'])) {
      $errors[] = "Subject cannot be blank.";
    }

    // menu_name
    if(is_blank($page['menu_name'])) {
      $errors[] = "Name cannot be blank.";
    } elseif(!has_length($page['menu_name'], ['min' => 2, 'max' => 255])) {
      $errors[] = "Name must be between 2 and 255 characters.";
    }
    $current_id = $page['id'] ?? '0';
    if(!has_unique_page_menu_name($page['menu_name'], $current_id)) {
      $errors[] = "Menu name must be unique.";
    }


    // position
    // Make sure we are working with an integer
    $postion_int = (int) $page['position'];
    if($postion_int <= 0) {
      $errors[] = "Position must be greater than zero.";
    }
    if($postion_int > 999) {
      $errors[] = "Position must be less than 999.";
    }

    // visible
    // Make sure we are working with a string
    $visible_str = (string) $page['visible'];
    if(!has_inclusion_of($visible_str, ["0","1"])) {
      $errors[] = "Visible must be true or false.";
    }

    // content
    if(is_blank($page['content'])) {
      $errors[] = "Content cannot be blank.";
    }

    return $errors;
  }

  function insert_page($page) {
    global $db;

    $errors = validate_page($page);
    if(!empty($errors)) {
      return $errors;
    }

    shift_page_positions(0, $page['position'], $page['subject_id']);

    $sql = "INSERT INTO pages ";
    $sql .= "(subject_id, menu_name, position, visible, content) ";
    $sql .= "VALUES (";
    $sql .= "'" . db_escape($db, $page['subject_id']) . "',";
    $sql .= "'" . db_escape($db, $page['menu_name']) . "',";
    $sql .= "'" . db_escape($db, $page['position']) . "',";
    $sql .= "'" . db_escape($db, $page['visible']) . "',";
    $sql .= "'" . db_escape($db, $page['content']) . "'";
    $sql .= ")";
    $result = mysqli_query($db, $sql);
    // For INSERT statements, $result is true/false
    if($result) {
      return true;
    } else {
      // INSERT failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }

  function update_page($page) {
    global $db;

    $errors = validate_page($page);
    if(!empty($errors)) {
      return $errors;
    }

    $old_page = find_page_by_id($page['id']);
    $old_position = $old_page['position'];
    shift_page_positions($old_position, $page['position'], $page['subject_id'], $page['id']);

    $sql = "UPDATE pages SET ";
    $sql .= "subject_id='" . db_escape($db, $page['subject_id']) . "', ";
    $sql .= "menu_name='" . db_escape($db, $page['menu_name']) . "', ";
    $sql .= "position='" . db_escape($db, $page['position']) . "', ";
    $sql .= "visible='" . db_escape($db, $page['visible']) . "', ";
    $sql .= "content='" . db_escape($db, $page['content']) . "' ";
    $sql .= "WHERE id='" . db_escape($db, $page['id']) . "' ";
    $sql .= "LIMIT 1";

    $result = mysqli_query($db, $sql);
    // For UPDATE statements, $result is true/false
    if($result) {
      return true;
    } else {
      // UPDATE failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }

  }

  function delete_page($id) {
    global $db;

    $old_page = find_page_by_id($id);
    $old_position = $old_page['position'];
    shift_page_positions($old_position, 0, $old_page['subject_id'], $id);

    $sql = "DELETE FROM pages ";
    $sql .= "WHERE id='" . db_escape($db, $id) . "' ";
    $sql .= "LIMIT 1";
    $result = mysqli_query($db, $sql);

    // For DELETE statements, $result is true/false
    if($result) {
      return true;
    } else {
      // DELETE failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }

  function find_pages_by_subject_id($subject_id, $options=[]) {
    global $db;

    $visible = $options['visible'] ?? false;

    $sql = "SELECT * FROM pages ";
    $sql .= "WHERE subject_id='" . db_escape($db, $subject_id) . "' ";
    if($visible) {
      $sql .= "AND visible = true ";
    }
    $sql .= "ORDER BY position ASC";
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    return $result;
  }

  function count_pages_by_subject_id($subject_id, $options=[]) {
    global $db;

    $visible = $options['visible'] ?? false;

    $sql = "SELECT COUNT(id) FROM pages ";
    $sql .= "WHERE subject_id='" . db_escape($db, $subject_id) . "' ";
    if($visible) {
      $sql .= "AND visible = true ";
    }
    $sql .= "ORDER BY position ASC";
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    $row = mysqli_fetch_row($result);
    mysqli_free_result($result);
    $count = $row[0];
    return $count;
  }

  function shift_page_positions($start_pos, $end_pos, $subject_id, $current_id=0) {
    global $db;

    if($start_pos == $end_pos) { return; }

    $sql = "UPDATE pages ";
    if($start_pos == 0) {
      // new item, +1 to items greater than $end_pos
      $sql .= "SET position = position + 1 ";
      $sql .= "WHERE position >= '" . db_escape($db, $end_pos) . "' ";
    } elseif($end_pos == 0) {
      // delete item, -1 from items greater than $start_pos
      $sql .= "SET position = position - 1 ";
      $sql .= "WHERE position > '" . db_escape($db, $start_pos) . "' ";
    } elseif($start_pos < $end_pos) {
      // move later, -1 from items between (including $end_pos)
      $sql .= "SET position = position - 1 ";
      $sql .= "WHERE position > '" . db_escape($db, $start_pos) . "' ";
      $sql .= "AND position <= '" . db_escape($db, $end_pos) . "' ";
    } elseif($start_pos > $end_pos) {
      // move earlier, +1 to items between (including $end_pos)
      $sql .= "SET position = position + 1 ";
      $sql .= "WHERE position >= '" . db_escape($db, $end_pos) . "' ";
      $sql .= "AND position < '" . db_escape($db, $start_pos) . "' ";
    }
    // Exclude the current_id in the SQL WHERE clause
    $sql .= "AND id != '" . db_escape($db, $current_id) . "' ";
    $sql .= "AND subject_id = '" . db_escape($db, $subject_id) . "'";

    $result = mysqli_query($db, $sql);
    // For UPDATE statements, $result is true/false
    if($result) {
      return true;
    } else {
      // UPDATE failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }


  // Admins

  // Find all admins, ordered last_name, first_name
  function find_all_admins() {
    global $db;

    $sql = "SELECT * FROM admins ";
    $sql .= "ORDER BY last_name ASC, first_name ASC";
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    return $result;
  }

  function find_admin_by_id($id) {
    global $db;

    $sql = "SELECT * FROM admins ";
    $sql .= "WHERE id='" . db_escape($db, $id) . "' ";
    $sql .= "LIMIT 1";
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    $admin = mysqli_fetch_assoc($result); // find first
    mysqli_free_result($result);
    return $admin; // returns an assoc. array
  }

  function find_admin_by_username($username) {
    global $db;

    $sql = "SELECT * FROM admins ";
    $sql .= "WHERE username='" . db_escape($db, $username) . "' ";
    $sql .= "LIMIT 1";
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    $admin = mysqli_fetch_assoc($result); // find first
    mysqli_free_result($result);
    return $admin; // returns an assoc. array
  }

  function validate_admin($admin, $options=[]) {

    $password_required = $options['password_required'] ?? true;

    if(is_blank($admin['first_name'])) {
      $errors[] = "First name cannot be blank.";
    } elseif (!has_length($admin['first_name'], array('min' => 2, 'max' => 255))) {
      $errors[] = "First name must be between 2 and 255 characters.";
    }

    if(is_blank($admin['last_name'])) {
      $errors[] = "Last name cannot be blank.";
    } elseif (!has_length($admin['last_name'], array('min' => 2, 'max' => 255))) {
      $errors[] = "Last name must be between 2 and 255 characters.";
    }

    if(is_blank($admin['email'])) {
      $errors[] = "Email cannot be blank.";
    } elseif (!has_length($admin['email'], array('max' => 255))) {
      $errors[] = "Last name must be less than 255 characters.";
    } elseif (!has_valid_email_format($admin['email'])) {
      $errors[] = "Email must be a valid format.";
    }

    if(is_blank($admin['username'])) {
      $errors[] = "Username cannot be blank.";
    } elseif (!has_length($admin['username'], array('min' => 8, 'max' => 255))) {
      $errors[] = "Username must be between 8 and 255 characters.";
    } elseif (!has_unique_username($admin['username'], $admin['id'] ?? 0)) {
      $errors[] = "Username not allowed. Try another.";
    }

    if($password_required) {
      if(is_blank($admin['password'])) {
        $errors[] = "Password cannot be blank.";
      } elseif (!has_length($admin['password'], array('min' => 12))) {
        $errors[] = "Password must contain 12 or more characters";
      } elseif (!preg_match('/[A-Z]/', $admin['password'])) {
        $errors[] = "Password must contain at least 1 uppercase letter";
      } elseif (!preg_match('/[a-z]/', $admin['password'])) {
        $errors[] = "Password must contain at least 1 lowercase letter";
      } elseif (!preg_match('/[0-9]/', $admin['password'])) {
        $errors[] = "Password must contain at least 1 number";
      } elseif (!preg_match('/[^A-Za-z0-9\s]/', $admin['password'])) {
        $errors[] = "Password must contain at least 1 symbol";
      }

      if(is_blank($admin['confirm_password'])) {
        $errors[] = "Confirm password cannot be blank.";
      } elseif ($admin['password'] !== $admin['confirm_password']) {
        $errors[] = "Password and confirm password must match.";
      }
    }

    return $errors;
  }

  function insert_admin($admin) {
    global $db;

    $errors = validate_admin($admin);
    if (!empty($errors)) {
      return $errors;
    }

    $hashed_password = password_hash($admin['password'], PASSWORD_BCRYPT);

    $sql = "INSERT INTO admins ";
    $sql .= "(first_name, last_name, email, username, hashed_password) ";
    $sql .= "VALUES (";
    $sql .= "'" . db_escape($db, $admin['first_name']) . "',";
    $sql .= "'" . db_escape($db, $admin['last_name']) . "',";
    $sql .= "'" . db_escape($db, $admin['email']) . "',";
    $sql .= "'" . db_escape($db, $admin['username']) . "',";
    $sql .= "'" . db_escape($db, $hashed_password) . "'";
    $sql .= ")";
    $result = mysqli_query($db, $sql);

    // For INSERT statements, $result is true/false
    if($result) {
      return true;
    } else {
      // INSERT failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }

  function update_admin($admin) {
    global $db;

    $password_sent = !is_blank($admin['password']);

    $errors = validate_admin($admin, ['password_required' => $password_sent]);
    if (!empty($errors)) {
      return $errors;
    }

    $hashed_password = password_hash($admin['password'], PASSWORD_BCRYPT);

    $sql = "UPDATE admins SET ";
    $sql .= "first_name='" . db_escape($db, $admin['first_name']) . "', ";
    $sql .= "last_name='" . db_escape($db, $admin['last_name']) . "', ";
    $sql .= "email='" . db_escape($db, $admin['email']) . "', ";
    if($password_sent) {
      $sql .= "hashed_password='" . db_escape($db, $hashed_password) . "', ";
    }
    $sql .= "username='" . db_escape($db, $admin['username']) . "' ";
    $sql .= "WHERE id='" . db_escape($db, $admin['id']) . "' ";
    $sql .= "LIMIT 1";
    $result = mysqli_query($db, $sql);

    // For UPDATE statements, $result is true/false
    if($result) {
      return true;
    } else {
      // UPDATE failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }

  function delete_admin($admin) {
    global $db;

    $sql = "DELETE FROM admins ";
    $sql .= "WHERE id='" . db_escape($db, $admin['id']) . "' ";
    $sql .= "LIMIT 1;";
    $result = mysqli_query($db, $sql);

    // For DELETE statements, $result is true/false
    if($result) {
      return true;
    } else {
      // DELETE failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }


//----------------members------------------------//


    function find_all(){
    global $db;    
        
    $sql = "SELECT *FROM members ";
    $sql .= "ORDER BY id ASC";
    //echo $sql;
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    
    return $result;
    }

    function find_by_id($id){
        global $db;
        
        $sql = "SELECT *FROM members ";
        $sql .= "WHERE id='".db_escape($db, $id)."'";
//        echo " $sql ";
        $result = mysqli_query($db, $sql);
        confirm_result_set($result);

        $member = mysqli_fetch_assoc($result);
        mysqli_free_result($result);
        
        return $member; //Returns assoc array
    }

    function find_member_by_student_no($student_no){
            global $db;
        
       $sql = "SELECT *FROM members ";
        $sql .= "WHERE student_no='".db_escape($db, $student_no)."'";
//        echo " $sql ";
        $result = mysqli_query($db, $sql);
        confirm_result_set($result);

        $member = mysqli_fetch_assoc($result);
        mysqli_free_result($result);
        
        return $member; //Returns assoc array        
    }

     function validate($member) {

      $errors = [];

      // member_name 
      if(is_blank($member['member_name'])) {
        $errors[] = "Name cannot be blank.";
      }elseif(!has_length($member['member_name'], ['min' => 2, 'max' => 255])) {
        $errors[] = "Name must be between 2 and 255 characters.";
      }
         
    // member_surname 
      if(is_blank($member['member_surname'])) {
        $errors[] = "Surname cannot be blank.";
      }elseif(!has_length($member['member_surname'], ['min' => 2, 'max' => 255])) {
        $errors[] = "Surname must be between 2 and 255 characters.";
      }     

      // Position 
      if(is_blank($member['position'])) {
        $errors[] = "Position cannot be blank.";
      }elseif(!has_length($member['position'], ['min' => 2, 'max' => 255])) {
        $errors[] = "Position must be between 2 and 255 characters.";
      }
        //Valifdate Contact Number
         if(is_blank($member['contact_no'])){
             $errors[]= "Contact Number cannot be left blank.";
         }elseif(!($member['contact_no'])[0]=='0'){
             $errors[] = "First digit of contact number must be a zero.";
         }elseif(!is_numeric($member['contact_no'])){
           $errors[] = "Contact number must be all digits"; 
        }elseif(!(strlen($member['contact_no'])==10)){
           $errors[] = "Enter 10 digits on contact number."; 
        } 
         
      // Student number
         
       $current_id = $member['id']??'0'; //To ensure unique student no
      if(is_blank($member['student_no'])) {
        $errors[] = "Student number cannot be blank.";
      }elseif(!has_length($member['student_no'], ['min' =>9, 'max' => 9])) {
        $errors[] = "Student number invalid.";     }elseif(!has_unique_student_no($member['student_no'], $current_id)){
            $errors[]= "Student number already exist, enter your own.";
        }
                 
         
      // Degree name 
      if(is_blank($member['degree_name'])) {
        $errors[] = "Degree name cannot be blank.";
      }elseif(!has_length($member['degree_name'], ['min' => 10, 'max' => 255])) {
        $errors[] = "Degree name must be between 10 and 255 characters.";
      }         

      // Bursary name 
      if(is_blank($member['bursary_name'])) {
        $errors[] = "Bursary cannot be blank.";
      }elseif(!has_length($member['bursary_name'], ['min' => 2, 'max' => 255])) {
        $errors[] = "Bursary name must be between 2 and 255 characters.";
      }
         
      return $errors;
    }


    function has_unique_student_no($student_no, $current_id='0'){
        global $db;
        
        $sql = "SELECT *FROM members ";
        $sql .= "WHERE student_no='".db_escape($db, $student_no)."' ";
        $sql .="AND id != '".db_escape($db, $current_id)."'";
        
        $member_set = mysqli_query($db, $sql);
        $member_count = mysqli_num_rows($member_set);
        mysqli_free_result($member_set);
        
        return $member_count ===0;
    }

    function insert($member){
        global $db;
        
        $errors = validate($member);
        
        if(!empty($errors)){
            return $errors;
        }
        $member['email_address'] = (strtoupper($member['student_no']))."@myuct.ac.za";
        
        $sql = "INSERT INTO members ";
        $sql .= "(student_no, member_name, member_surname, position, email_address, contact_no, degree_name, fuculty, year_of_study, residence, is_tutor, is_mentor, mentor_name, bursary_name, home_centre, gender, reg_date) ";
        $sql .= "VALUES (";
        $sql .= "'" . db_escape($db, strtoupper($member['student_no'])) . "',";
        $sql .= "'" . db_escape($db, ucwords($member['member_name'])) . "',";
        $sql .= "'" . db_escape($db, ucwords($member['member_surname'])) . "',";
        $sql .= "'" . db_escape($db, $member['position']) . "',";
        $sql .= "'" . db_escape($db, $member['email_address']) . "',";
        $sql .= "'" . db_escape($db, $member['contact_no']) . "',";
        $sql .= "'" . db_escape($db, ucwords($member['degree_name'])) . "',";
        $sql .= "'" . db_escape($db, ucwords($member['fuculty'])) . "',";
        $sql .= "'" . db_escape($db, $member['year_of_study']) . "',";
        $sql .= "'" . db_escape($db, $member['residence']) . "',";
        $sql .= "'" . db_escape($db, $member['is_tutor']) . "',";
        $sql .= "'" . db_escape($db, $member['is_mentor']) . "',";
        $sql .= "'" . db_escape($db, $member['mentor_name']) . "',";
        $sql .= "'" . db_escape($db, ucwords($member['bursary_name'])) . "',";
        $sql .= "'" . db_escape($db, $member['home_centre']) . "',";
        $sql .= "'" . db_escape($db, $member['gender']) . "',";
        $sql .= "'" . db_escape($db, $member['reg_date']) . "'";
        $sql .= ")";

        $result = mysqli_query($db, $sql);
        //For INSERT statement, $result is true/false

            if ($result){
              return true;
            }else{
               echo mysqli_error($db);
                db_disconnect($db);
                exit;
            }
    }

    function update($member){
        global $db;
        
        $errors = validate($member);
        
        if(!empty($errors)){
            return $errors;
        }
        $member['email_address'] = (strtoupper($member['student_no']))."@myuct.ac.za";
        
        $sql = "UPDATE members SET ";
        $sql .= "student_no='" .db_escape($db, strtoupper($member['student_no']))."',";
        $sql .= "member_name='" .db_escape($db, ucwords($member['member_name']))."',";
        $sql .= "member_surname='" .db_escape($db, ucwords($member['member_surname']))."',";
        $sql .= "position='" .db_escape($db, $member['position'])."',";
        $sql .= "email_address='" .db_escape($db, $member['email_address'])."',";
        $sql .= "contact_no='" .db_escape($db, $member['contact_no'])."',";
        $sql .= "degree_name='" .db_escape($db, ucwords($member['degree_name']))."',";
        $sql .= "fuculty='" .db_escape($db, ($member['fuculty']))."',";
        $sql .= "year_of_study='" .db_escape($db, $member['year_of_study'])."',";
        $sql .= "residence='" .db_escape($db, $member['residence'])."',";
        $sql .= "is_tutor='" .db_escape($db, $member['is_tutor'])."',";
        $sql .= "is_mentor='" .db_escape($db, $member['is_mentor'])."',";
        $sql .= "mentor_name='" .db_escape($db, $member['mentor_name'])."',";
        $sql .= "bursary_name='" .db_escape($db, ucwords($member['bursary_name']))."',";
        $sql .= "home_centre='" .db_escape($db, $member['home_centre'])."',";
        $sql .= "gender='" .db_escape($db, $member['gender'])."' ";
        $sql .="WHERE id='".db_escape($db, $member['id'])."' ";
        $sql .="LIMIT 1";
        

        $result =mysqli_query($db, $sql);
        //For update statements, $result is true/false

        if ($result){
            return true;
        }else{
            //UPDATE failed
            echo mysqli_error($db);
            db_disconnect($db);
            exit;
        }

    }

    function delete($id){
        global $db;
        
        $sql = "DELETE FROM members ";
        $sql .="WHERE id='".db_escape($db, $id)."' ";
        $sql .="LIMIT 1";

        $result = mysqli_query($db, $sql);

        if($result){
            return true;
        }else{
             //DELETE failed
                echo mysqli_error($db);
                db_disconnect($db);
                exit;
        }
        }


//---------------------------Exec------------------------------//


    function find_all_exec(){
    global $db;    
        
    $sql = "SELECT *FROM executive ";
    $sql .= "ORDER BY id ASC";
    //echo $sql;
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    
    return $result;
    }

    function find_exec_by_id($id){
        global $db;
        
        $sql = "SELECT *FROM executive ";
        $sql .= "WHERE id='".db_escape($db, $id)."'";
//        echo " $sql ";
        $result = mysqli_query($db, $sql);
        confirm_result_set($result);

        $exec = mysqli_fetch_assoc($result);
        mysqli_free_result($result);
        
        return $exec; //Returns assoc array
    }

  function find_exec_by_student_no($student_no){
            global $db;
        
       $sql = "SELECT *FROM executive ";
        $sql .= "WHERE student_no='".db_escape($db, $student_no)."'";
//        echo " $sql ";
        $result = mysqli_query($db, $sql);
        confirm_result_set($result);

        $exec = mysqli_fetch_assoc($result);
        mysqli_free_result($result);
        
        return $exec; //Returns assoc array        
    }

     function validate_exec($exec, $options=[]) {
         
     $password_required = $options['password_required'] ?? true;

      $errors = [];
        
         $editing = $exec['editing']?? false;
         
      // Student number
      //Not allowed to change student number when editing
        if(!$editing){ 
       $current_id = $exec['id']??'0'; //To ensure unique student no
      if(is_blank($exec['student_no'])) {
        $errors[] = "Student number cannot be blank.";
      }elseif(!has_length($exec['student_no'], ['min' =>9, 'max' => 9])) {
        $errors[] = "Student number invalid.";     }elseif(!exec_has_unique_student_no($exec['student_no'], $current_id)){
            $errors[]= "The member is already in exec, click 'back to list' to check the list.";
        }
            }
         
        //For when editing exec because its fine to leave password blank when editing exec.
       if($password_required) {
          if(is_blank($exec['password'])) {
            $errors[] = "Password cannot be blank.";
          } elseif (!has_length($exec['password'], array('min' => 12))) {
            $errors[] = "Password must contain 12 or more characters";
          } elseif (!preg_match('/[A-Z]/', $exec['password'])) {
            $errors[] = "Password must contain at least 1 uppercase letter";
          } elseif (!preg_match('/[a-z]/', $exec['password'])) {
            $errors[] = "Password must contain at least 1 lowercase letter";
          } elseif (!preg_match('/[0-9]/', $exec['password'])) {
            $errors[] = "Password must contain at least 1 number";
          } elseif (!preg_match('/[^A-Za-z0-9\s]/', $exec['password'])) {
            $errors[] = "Password must contain at least 1 symbol";
          }

          if(is_blank($exec['confirm_password'])) {
            $errors[] = "Confirm password cannot be blank.";
          } elseif ($exec['password'] !== $exec['confirm_password']) {
            $errors[] = "Password and confirm password must match.";
          }
        }

 

      return $errors;
    }

    function exec_has_unique_student_no($student_no, $current_id='0'){
        global $db;
        
        $sql = "SELECT *FROM executive ";
        $sql .= "WHERE student_no='".db_escape($db, $student_no)."' ";
        $sql .="AND id != '".db_escape($db, $current_id)."'";
        
        $exec_set = mysqli_query($db, $sql);
        $exec_count = mysqli_num_rows($exec_set);
        mysqli_free_result($exec_set);
        
        return $exec_count ===0;
    }


    function insert_exec($exec){
        global $db;
        
        $errors = validate_exec($exec);
        
        if(!empty($errors)){
            return $errors;
        }
        
        $hashed_password = password_hash($exec['password'], PASSWORD_BCRYPT);

        
        $sql = "INSERT INTO executive ";
        $sql .= "(student_no, exec_position, reg_date, hashed_password) ";
        $sql .= "VALUES (";
        $sql .= "'" . db_escape($db, strtoupper($exec['student_no'])) . "',";
        $sql .= "'" . db_escape($db, $exec['exec_position']) . "',";
        $sql .= "'" . db_escape($db, $exec['reg_date']) . "',";
        $sql .= "'" . db_escape($db, $hashed_password) . "'";
        $sql .= ")";
        $result = mysqli_query($db, $sql);
        //For INSERT statement, $result is true/false

            if ($result){
              return true;
            }else{
               echo mysqli_error($db);
                db_disconnect($db);
                exit;
            }
    }

    function update_exec($exec){
        global $db;
        
        $password_sent = !is_blank($exec['password']);
        
         $errors = validate_exec($exec, ['password_required' => $password_sent]);
            if (!empty($errors)) {
              return $errors;
            }
        
        $sql = "UPDATE executive SET ";
        if($password_sent) {
          $sql .= "hashed_password='" . db_escape($db, $hashed_password) . "', ";
            }
        $sql .= "exec_position='" .db_escape($db, $exec['exec_position'])."' ";
        $sql .="WHERE id='".db_escape($db, $exec['id'])."' ";
        $sql .="LIMIT 1";

        $result =mysqli_query($db, $sql);
        //For update statements, $result is true/false

        if ($result){
            return true;
        }else{
            //UPDATE failed
            echo mysqli_error($db);
            db_disconnect($db);
            exit;
        }

    }

    function delete_exec($id){
        global $db;
        
        $sql = "DELETE FROM executive ";
        $sql .="WHERE id='".db_escape($db, $id)."' ";
        $sql .="LIMIT 1";

        $result = mysqli_query($db, $sql);

        if($result){
            return true;
        }else{
             //DELETE failed
                echo mysqli_error($db);
                db_disconnect($db);
                exit;
        }
        }


//--------------------------------Tutors-----------------------------------//
  function find_all_tutors(){
    global $db;    
        
    $sql = "SELECT *FROM tutors ";
    $sql .= "ORDER BY id ASC";
    //echo $sql;
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    
    return $result;
    }

    function find_tutor_by_id($id){
        global $db;
        
        $sql = "SELECT *FROM tutors ";
        $sql .= "WHERE id='".db_escape($db, $id)."'";
//        echo " $sql ";
        $result = mysqli_query($db, $sql);
        confirm_result_set($result);

        $tutor = mysqli_fetch_assoc($result);
        mysqli_free_result($result);
        
        return $tutor; //Returns assoc array
    }

     function validate_tutor($tutor) {

      $errors = [];
         
      // Student number         
       $current_id = $tutor['id']??'0'; //To ensure unique student no
      if(is_blank($tutor['student_no'])) {
        $errors[] = "Student number cannot be blank.";
      }elseif(!has_length($tutor['student_no'], ['min' =>9, 'max' => 9])) {
        $errors[] = "Student number invalid.";     }elseif(!tutor_has_unique_student_no($tutor['student_no'], $current_id)){
            $errors[]= "The member is already a mentor, click 'back to list' to check the list.";
        }
         
      // Courses to tutor         
      if(is_blank($tutor['tutor_courses'])) {
        $errors[] = "Please fill in the courses you want to tutor.";
      }
      // visible
      // Make sure we are working with a string
      $visible_str = (string) $tutor['visible'];
      if(!has_inclusion_of($visible_str, ["0","1"])) {
        $errors[] = "Visible must be true or false.";
      }
 

      return $errors;
    }

    function tutor_has_unique_student_no($student_no, $current_id='0'){
        global $db;
        
        $sql = "SELECT *FROM tutors ";
        $sql .= "WHERE student_no='".db_escape($db, $student_no)."' ";
        $sql .="AND id != '".db_escape($db, $current_id)."'";
        
        $tutor_set = mysqli_query($db, $sql);
        $tutor_count = mysqli_num_rows($tutor_set);
        mysqli_free_result($tutor_set);
        
        return $tutor_count ===0;
    }


    function insert_tutor($tutor){
        global $db;
        
        $errors = validate_tutor($tutor);
        
        if(!empty($errors)){
            return $errors;
        }
        
        $sql = "INSERT INTO tutors ";
        $sql .= "(student_no, tutor_courses, reg_date, visible) ";
        $sql .= "VALUES (";
        $sql .= "'" . db_escape($db, strtoupper($tutor['student_no'])) . "',";
        $sql .= "'" . db_escape($db, $tutor['tutor_courses']) . "',";
        $sql .= "'" . db_escape($db, $tutor['reg_date']) . "',";
        $sql .= "'" . db_escape($db, $tutor['visible']) . "'";
        $sql .= ")";
            echo $sql;
        $result = mysqli_query($db, $sql);
        //For INSERT statement, $result is true/false

            if ($result){
              return true;
            }else{
               echo mysqli_error($db);
                db_disconnect($db);
                exit;
            }
    }

    function update_tutor($tutor){
        global $db;
        
        $errors = validate_tutor($tutor);
        
        if(!empty($errors)){
            return $errors;
        }
        
        $sql = "UPDATE tutors SET ";
        $sql .= "student_no='" .db_escape($db, strtoupper($tutor['student_no']))."',";
        $sql .= "tutor_courses='" .db_escape($db, $tutor['tutor_courses'])."',";
        $sql .= "visible='" .db_escape($db, $tutor['visible'])."' ";
        $sql .="WHERE id='".db_escape($db, $tutor['id'])."' ";
        $sql .="LIMIT 1";

        $result =mysqli_query($db, $sql);
        //For update statements, $result is true/false

        if ($result){
            return true;
        }else{
            //UPDATE failed
            echo mysqli_error($db);
            db_disconnect($db);
            exit;
        }

    }

    function delete_tutor($id){
        global $db;
        
        $sql = "DELETE FROM tutors ";
        $sql .="WHERE id='".db_escape($db, $id)."' ";
        $sql .="LIMIT 1";

        $result = mysqli_query($db, $sql);

        if($result){
            return true;
        }else{
             //DELETE failed
                echo mysqli_error($db);
                db_disconnect($db);
                exit;
        }
        }

  
//----------------------------------Mentors--------------------------------//

    function find_all_mentors(){
    global $db;    
        
    $sql = "SELECT *FROM mentors ";
    $sql .= "ORDER BY id ASC";
    //echo $sql;
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    
    return $result;
    }

    function find_mentor_by_id($id){
        global $db;
        
        $sql = "SELECT *FROM mentors ";
        $sql .= "WHERE id='".db_escape($db, $id)."'";
//        echo " $sql ";
        $result = mysqli_query($db, $sql);
        confirm_result_set($result);

        $mentor = mysqli_fetch_assoc($result);
        mysqli_free_result($result);
        
        return $mentor; //Returns assoc array
    }

     function validate_mentor($mentor) {

      $errors = [];
   
      // Student number
         
       $current_id = $mentor['id']??'0'; //To ensure unique student no
      if(is_blank($mentor['student_no'])) {
        $errors[] = "Student number cannot be blank.";
      }elseif(!has_length($mentor['student_no'], ['min' =>9, 'max' => 9])) {
        $errors[] = "Student number invalid.";     }elseif(!mentor_has_unique_student_no($mentor['student_no'], $current_id)){
            $errors[]= "The member is already a mentor, click 'back to list' to check the list.";
        }
         //Mentees names
//         $set = ['None'];
//         if(is_blank($mentor['mentee_names'])) {
//        $errors[] = "Mentee names cannot be blank.";
//      }

      // visible
      // Make sure we are working with a string
      $visible_str = (string) $mentor['visible'];
      if(!has_inclusion_of($visible_str, ["0","1"])) {
        $errors[] = "Visible must be true or false.";
      }
 

      return $errors;
    }

    function mentor_has_unique_student_no($student_no, $current_id='0'){
        global $db;
        
        $sql = "SELECT *FROM mentors ";
        $sql .= "WHERE student_no='".db_escape($db, $student_no)."' ";
        $sql .="AND id != '".db_escape($db, $current_id)."'";
        
        $mentor_set = mysqli_query($db, $sql);
        $mentor_count = mysqli_num_rows($mentor_set);
        mysqli_free_result($mentor_set);
        
        return $mentor_count ===0;
    }


    function insert_mentor($mentor){
        global $db;
        
        $errors = validate_mentor($mentor);
        
        if(!empty($errors)){
            return $errors;
        }
        
        $sql = "INSERT INTO mentors ";
        $sql .= "(student_no, mentee_names, reg_date, visible) ";
        $sql .= "VALUES (";
        $sql .= "'" . db_escape($db, strtoupper($mentor['student_no'])) . "',";
        $sql .= "'" . db_escape($db, $mentor['mentee_names']) . "',";
        $sql .= "'" . db_escape($db, $mentor['reg_date']) . "',";
        $sql .= "'" . db_escape($db, $mentor['visible']) . "'";
        $sql .= ")";

        $result = mysqli_query($db, $sql);
        //For INSERT statement, $result is true/false

            if ($result){
              return true;
            }else{
               echo mysqli_error($db);
                db_disconnect($db);
                exit;
            }
    }

    function update_mentor($mentor){
        global $db;
        
        $errors = validate_mentor($mentor);
        
        if(!empty($errors)){
            return $errors;
        }
        
        $sql = "UPDATE mentors SET ";
        $sql .= "student_no='" .db_escape($db, strtoupper($mentor['student_no']))."',";
        $sql .= "mentee_names='" .db_escape($db, $mentor['mentee_names'])."',";
        $sql .= "reg_date='" .db_escape($db, $mentor['reg_date'])."',";
        $sql .= "visible='" .db_escape($db, $mentor['visible'])."' ";
        $sql .="WHERE id='".db_escape($db, $mentor['id'])."' ";
        $sql .="LIMIT 1";

        $result =mysqli_query($db, $sql);
        //For update statements, $result is true/false

        if ($result){
            return true;
        }else{
            //UPDATE failed
            echo mysqli_error($db);
            db_disconnect($db);
            exit;
        }

    }

    function delete_mentor($id){
        global $db;
        
        $sql = "DELETE FROM mentors ";
        $sql .="WHERE id='".db_escape($db, $id)."' ";
        $sql .="LIMIT 1";

        $result = mysqli_query($db, $sql);

        if($result){
            return true;
        }else{
             //DELETE failed
                echo mysqli_error($db);
                db_disconnect($db);
                exit;
        }
        }


?>
