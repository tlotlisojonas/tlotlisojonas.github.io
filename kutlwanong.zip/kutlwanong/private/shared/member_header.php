<?php
  if(!isset($page_title)) { $page_title = 'Public Area'; }
?>

<!doctype html>

<html lang="en">
  <head>
    <title>Promaths - <?php echo h($page_title); ?></title>
    <meta charset="utf-8">
    <link rel="stylesheet" media="all" href="<?php echo url_for('/stylesheets/staff.css'); ?>" />
  </head>

  <body>
    <header id="member_header">
      <h1>Promaths Public Area</h1>
    </header>

    <navigation>
      <ul>
          <div id='menu-click' class="member_header">
        <li><a href="<?php echo url_for('index.php'); ?>" target="_blank">Go Public</a></li>
            </div>
      </ul>
    </navigation>

    <?php echo display_session_message(); ?>
