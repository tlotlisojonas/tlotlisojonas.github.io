  <footer>
        <div class="contact">
            <a class="mail" href="uctpromathsalumni@gmail.com">Email</a>
            <a class="twitter" href="https://twitter.com/login?lang=en" target="_blank">Twitter</a>
            <a class="fb" href="https://www.facebook.com/" target="_blank">Facebook</a>
            <a class="ig" href="https://www.instagram.com/tlotliso_jones/?hl=en" target="_blank">Instagram</a>
        </div>

    <?php include 'copyright.php'; ?> | Designed by <a class="dev_link" href="https://tlotlisojonas.github.io/" a>Tlotliso Jonas</a
  </footer >


  </body>
</html>

<?php
  db_disconnect($db);
?>
