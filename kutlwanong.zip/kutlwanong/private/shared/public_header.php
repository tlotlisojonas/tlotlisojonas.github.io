<!doctype html>

<html lang="en">
  <head>
    <title>UCT Promaths <?php if(isset($page_title)) { echo '- ' . h($page_title); } ?></title>
    <meta charset="utf-8">
    <link rel="stylesheet" media="all" href="<?php echo url_for('/stylesheets/public.css'); ?>" />
  </head>

  <body>

    <header>
        <dl id="header_display">
         <dt><a href="<?php echo url_for('staff/login.php'); ?>" target="_blank">Admin login</a></dt>
        <dd>
        <a id="header_icon" href="<?php echo url_for('/index.php'); ?>">
          <img id="header_icon" src="<?php echo url_for('/images/header.png'); ?>"  alt="" />
        </a>
         </dd>
       </dl>
    </header>
    <?php echo display_session_message(); ?>
