<footer>
  <?php include 'copyright.php'; ?> | Designed by <a class="dev_link" href="https://tlotlisojonas.github.io/" a>Tlotliso Jonas</a>
</footer>

</body>
</html>

<?php
  db_disconnect($db);
?>
