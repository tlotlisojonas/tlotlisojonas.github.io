<?php
  if(!isset($page_title)) { $page_title = 'Staff Area'; }
?>

<!doctype html>

<html lang="en">
  <head>
    <title>Promaths - <?php echo h($page_title); ?></title>
    <meta charset="utf-8">
    <link rel="stylesheet" media="all" href="<?php echo url_for('/stylesheets/staff.css'); ?>" />
  </head>

  <body>
    <header>
      <h1>Promaths Admin Area</h1>
    </header>

    <navigation>
      <ul>
          
          <div id="user-display">
          <li>User Name: <?php echo $_SESSION['student_no'] ?? 'No User'; ?></li>
          </div>
          <div id='menu-click'>
        <li><a href="<?php echo url_for('index.php'); ?>" target="_blank">Go Public</a></li>
        <li><a href="<?php echo url_for('/staff/index.php'); ?>">Menu</a></li>
        <li><a href="<?php echo url_for('/staff/logout.php'); ?>">Logout</a></li>
            </div>
      </ul>
    </navigation>

    <?php echo display_session_message(); ?>
