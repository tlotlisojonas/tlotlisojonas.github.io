<div id="hero-image">
  <img src="images/homepage_pictures/WP_20160130_14_32_25_Pro.jpg" width="500" height="200" alt="" />
</div>

<div id="content">

  <h2>In all our events we always remind our family about the purpose and the aim of Promaths, this is to ensure that Promaths maintains its meaning.</h2>

  <div id="service-blocks">
    <div class="service">
      <img src="images/homepage_pictures/44.jpg" width="250" height="166" alt="Family in front of sold home" />
      <h1>Are from Promaths back home?</h1>
      <p>There's no place like home, and UCT Promaths can be your new home.</p>
      <p><a href="#" class="findout nmore">Findout More...</a> </p>
    </div>

    <div class="service">
      <img src="images/homepage_pictures/promaths.jpg" width="250" height="166" alt="Father and daughter discussing finances" />
      <h1>Heared of the upcomig event?</h1>
      <p>We are plannig something big for our Promaths family for this coming holydays.</p>
      <p><a href="#" class="readnmore">Read More...</a> </p>
    </div>

    <div class="service">
      <img src="images/homepage_pictures/tlotliso.jpg" width="250" height="166" alt="Small business owner" />
      <h1>Wep developer</h1>
      <p>Being part of Promaths made me feel like I am part of something <strong>REAL</strong> and <strong>BIG</strong>, I designed this website to show how much I appreciate Promaths.</p>
      <p><a href="#" class="readmore">Read More...</a> </p>
    </div>
  </div>

</div>
