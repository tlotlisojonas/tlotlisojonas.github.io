<?php
require_once('../private/initialize.php');
?>

<?php include(SHARED_PATH . '/member_header.php'); ?>


  <div id="login">


  </div>








<?php include(SHARED_PATH . '/member_footer.php'); ?>
