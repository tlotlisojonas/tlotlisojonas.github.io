<?php 

require_once('../../../private/initialize.php'); 
require_login();

if(!isset($_GET['id'])){
    redirect_to(url_for('/staff/exec/index.php'));
}else{

    $id = $_GET['id'];
    $exec = find_exec_by_id($id);
    $member = find_by_id($id);
}

if(is_post_request()){
    
    //Initialize $exec
    $exec =[];
    
    //-------------Collect the submitted data from $_POST array into $exec array--------//
    $exec['id'] = $id;
    $exec['exec_position'] = $_POST['exec_position']??'';
    $exec['password'] = $_POST['password'] ?? '';
    $exec['confirm_password'] = $_POST['confirm_password'] ?? '';
    $exec['editing'] = true;
    
    
    $result = update_exec($exec);
    
    if($result===true){
        $_SESSION['message'] = "Exec member edited succesfully!";
        redirect_to(url_for('/staff/exec/show.php?id='.h(u($id))));
    }else{
        $errors = $result;
    }
}

?>

<?php $page_title = 'Edit Exec Member'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">
<br>
<br>

  <a class="back-link" href="<?php echo url_for('/staff/exec/index.php'); ?>">&laquo; Back to List</a>

  <div class="subject edit">
    <h1>Edit <?php echo $member['member_name']. " ".$member['member_surname'] ; ?></h1>     
  </div>
<!---------------------------Display Errors If Any-------------------------->
    <?php echo display_errors($errors); ?>

      <div>
    <form action="<?php echo url_for('/staff/exec/edit.php?id='.h(u($id))); ?>" method="post">
      <dl>
        <dt>Exec Position</dt>
        <dd>        
        <select name="exec_position">
        <?php
          for($a=0; $a <= (count($society_positions)-1); $a++) {
            echo "<option value=\"$society_positions[$a]\"";
            if($exec["exec_position"] == $society_positions[$a]) {
              echo " selected";
            }
            echo ">$society_positions[$a]</option>";
          }
        ?>
        </select>
          </dd>
      </dl>
      <dl>
        <dt>Password</dt>
        <dd><input type="password" name="password" value="" /></dd>
      </dl>
      <dl>
        <dt>Confirm Password</dt>
        <dd><input type="password" name="confirm_password" value="" /></dd>
      </dl>
      <p>
        Passwords should be at least 12 characters and include at least one uppercase letter, lowercase letter, number, and symbol.
      </p>
      <br />
        
      <div id="operations">
        <input type="submit" value="Submit" />
      </div>
    </form>
      
  </div>

    
</div>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
