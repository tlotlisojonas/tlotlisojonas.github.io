<?php
    

//---------------------------Subjects------------------------------//

    function find_all_exec($data_base_table){
    global $db;    
        
    $sql = "SELECT *FROM $data_base_table ";
    $sql .= "ORDER BY id ASC";
    //echo $sql;
    $result = mysqli_query($db, $sql);
    comfirm_result_set($result);
    
    return $result;
    }

    function find_exec_by_id($id, $data_base_table){
        global $db;
        
        $sql = "SELECT *FROM $data_base_table ";
        $sql .= "WHERE id='".db_escape($db, $id)."'";
//        echo " $sql ";
        $result = mysqli_query($db, $sql);
        comfirm_result_set($result);

        $exec = mysqli_fetch_assoc($result);
        mysqli_free_result($result);
        
        return $exec; //Returns assoc array
    }

     function validate_exec($exec, $data_base_table) {

      $errors = [];

      // member_name 
      if(is_blank($exec['member_name'])) {
        $errors[] = "Name cannot be blank.";
      }elseif(!has_length($exec['member_name'], ['min' => 2, 'max' => 255])) {
        $errors[] = "Name must be between 2 and 255 characters.";
      }
         
    // member_surname 
      if(is_blank($exec['member_surname'])) {
        $errors[] = "Surname cannot be blank.";
      }elseif(!has_length($exec['member_surname'], ['min' => 2, 'max' => 255])) {
        $errors[] = "Surname must be between 2 and 255 characters.";
      }     

      // Position 
      if(is_blank($exec['position'])) {
        $errors[] = "Position cannot be blank.";
      }elseif(!has_length($exec['position'], ['min' => 2, 'max' => 255])) {
        $errors[] = "Position must be between 2 and 255 characters.";
      }
        //Valifdate Contact Number
         if(is_blank($exec['contact_no'])){
             $errors[]= "Contact Number cannot be left blank.";
         }elseif(!($exec['contact_no'])[0]=='0'){
             $errors[] = "First digit of contact number must be a zero.";
         }elseif(!is_numeric($exec['contact_no'])){
           $errors[] = "Contact number must be all digits"; 
        }elseif(!(strlen($exec['contact_no'])==10)){
           $errors[] = "Enter 10 digits on contact number."; 
        } 
         
      // Student number
         
       $current_id = $exec['id']??'0'; //To ensure unique student no
      if(is_blank($exec['student_no'])) {
        $errors[] = "Student number cannot be blank.";
      }elseif(!has_length($exec['student_no'], ['min' =>9, 'max' => 9])) {
        $errors[] = "Student number invalid.";     }elseif(!has_unique_student_no($exec['student_no'], $current_id, $data_base_table??'executive')){
            $errors[]= "Student number already exist, enter your own.";
        }
         
      // Degree name 
      if(is_blank($exec['degree_name'])) {
        $errors[] = "Degree name cannot be blank.";
      }elseif(!has_length($exec['degree_name'], ['min' => 10, 'max' => 255])) {
        $errors[] = "Degree name must be between 10 and 255 characters.";
      }         

      // Bursary name 
      if(is_blank($exec['bursary_name'])) {
        $errors[] = "Bursary cannot be blank.";
      }elseif(!has_length($exec['bursary_name'], ['min' => 2, 'max' => 255])) {
        $errors[] = "Bursary name must be between 2 and 255 characters.";
      }
         

         //Mentees names
         $set = ['None'];
         if(is_blank($exec['mentee_names'])) {
        $errors[] = "Mentee names cannot be blank.";
      }

      // visible
      // Make sure we are working with a string
      $visible_str = (string) $exec['visible'];
      if(!has_inclusion_of($visible_str, ["0","1"])) {
        $errors[] = "Visible must be true or false.";
      }
        //Validate email address    

      return $errors;
    }

    function has_unique_student_no($student_no, $current_id='0', $data_base_table){
        global $db;
        
        $sql = "SELECT *FROM $data_base_table ";
        $sql .= "WHERE student_no='".db_escape($db, $student_no)."' ";
        $sql .="AND id != '".db_escape($db, $current_id)."'";
        
        $exec_set = mysqli_query($db, $sql);
        $exec_count = mysqli_num_rows($exec_set);
        mysqli_free_result($exec_set);
        
        return $exec_count ===0;
    }


    function insert_exec($exec, $data_base_table){
        global $db;
        
        $errors = validate_exec($exec);
        
        if(!empty($errors)){
            return $errors;
        }
        $exec['email_address'] = (strtoupper($exec['student_no']))."@myuct.ac.za";
        
        $sql = "INSERT INTO $data_base_table ";
        $sql .= "(student_no, member_name, member_surname, position, email_address, contact_no, degree_name, year_of_study, residence, is_tutor, mentor, mentee_names, mentor_name, bursary_name, home_centre, gender, reg_date, visible) ";
        $sql .= "VALUES (";
        $sql .= "'" . db_escape($db, strtoupper($exec['student_no'])) . "',";
        $sql .= "'" . db_escape($db, ucwords($exec['member_name'])) . "',";
        $sql .= "'" . db_escape($db, ucwords($exec['member_surname'])) . "',";
        $sql .= "'" . db_escape($db, $exec['position']) . "',";
        $sql .= "'" . db_escape($db, $exec['email_address']) . "',";
        $sql .= "'" . db_escape($db, $exec['contact_no']) . "',";
        $sql .= "'" . db_escape($db, ucwords($exec['degree_name'])) . "',";
        $sql .= "'" . db_escape($db, $exec['year_of_study']) . "',";
        $sql .= "'" . db_escape($db, $exec['residence']) . "',";
        $sql .= "'" . db_escape($db, $exec['is_tutor']) . "',";
        $sql .= "'" . db_escape($db, $exec['mentor']) . "',";
        $sql .= "'" . db_escape($db, $exec['mentor_name']) . "',";
        $sql .= "'" . db_escape($db, ucwords($exec['mentee_names'])) . "',";
        $sql .= "'" . db_escape($db, ucwords($exec['bursary_name'])) . "',";
        $sql .= "'" . db_escape($db, $exec['home_centre']) . "',";
        $sql .= "'" . db_escape($db, $exec['gender']) . "',";
        $sql .= "'" . db_escape($db, $exec['reg_date']) . "',";
        $sql .= "'" . db_escape($db, $exec['visible']) . "'";
        $sql .= ")";

        $result = mysqli_query($db, $sql);
        //For INSERT statement, $result is true/false

            if ($result){
              return true;
            }else{
               echo mysqli_error($db);
                db_disconnect($db);
                exit;
            }
    }

    function update_exec($exec, $data_base_table){
        global $db;
        
        $errors = validate_exec($exec, $data_base_table??'executive');
        
        if(!empty($errors)){
            return $errors;
        }
        $exec['email_address'] = (strtoupper($exec['student_no']))."@myuct.ac.za";
        
        $sql = "UPDATE $data_base_table SET ";
        $sql .= "student_no='" .db_escape($db, strtoupper($exec['student_no']))."',";
        $sql .= "member_name='" .db_escape($db, ucwords($exec['member_name']))."',";
        $sql .= "member_surname='" .db_escape($db, ucwords($exec['member_surname']))."',";
        $sql .= "position='" .db_escape($db, $exec['position'])."',";
        $sql .= "email_address='" .db_escape($db, $exec['email_address'])."',";
        $sql .= "contact_no='" .db_escape($db, $exec['contact_no'])."',";
        $sql .= "degree_name='" .db_escape($db, ucwords($exec['degree_name']))."',";
        $sql .= "year_of_study='" .db_escape($db, $exec['year_of_study'])."',";
        $sql .= "residence='" .db_escape($db, $exec['residence'])."',";
        $sql .= "is_tutor='" .db_escape($db, $exec['is_tutor'])."',";
        $sql .= "mentor='" .db_escape($db, $exec['mentor'])."',";
        $sql .= "mentee_names='" .db_escape($db, ucwords($exec['mentee_names']))."',";
        $sql .= "mentor_name='" .db_escape($db, $exec['mentor_name'])."',";
        $sql .= "bursary_name='" .db_escape($db, ucwords($exec['bursary_name']))."',";
        $sql .= "home_centre='" .db_escape($db, $exec['home_centre'])."',";
        $sql .= "gender='" .db_escape($db, $exec['gender'])."',";
        $sql .= "visible='" .db_escape($db, $exec['visible'])."' ";
        $sql .="WHERE id='".db_escape($db, $exec['id'])."' ";
        $sql .="LIMIT 1";

        $result =mysqli_query($db, $sql);
        //For update statements, $result is true/false

        if ($result){
            return true;
        }else{
            //UPDATE failed
            echo mysqli_error($db);
            db_disconnect($db);
            exit;
        }

    }

    function delete_exec($id, $data_base_table){
        global $db;
        
        $sql = "DELETE FROM $data_base_table ";
        $sql .="WHERE id='".db_escape($db, $id)."' ";
        $sql .="LIMIT 1";

        $result = mysqli_query($db, $sql);

        if($result){
            return true;
        }else{
             //DELETE failed
                echo mysqli_error($db);
                db_disconnect($db);
                exit;
        }
        }

//---------------------------Pages------------------------------//





?>