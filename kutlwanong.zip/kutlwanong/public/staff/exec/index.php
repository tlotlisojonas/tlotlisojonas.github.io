<?php require_once('../../../private/initialize.php');
require_login();
 ?>

<?php


    $exec_set = find_all_exec();

?>

<?php $page_title = 'Executive'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">
  <div class="subjects listing">
    <h1>Executive</h1>

    <div class="actions">
      <a class="action" href="<?php echo url_for('/staff/exec/new.php'); ?>">Add New Exec Member</a>
    </div>
      <table class="list">
          <tr>
            <th>ID</th>
            <th>Student Number</th>
            <th>Name</th>
            <th>Surnmae</th>
            <th>Exec Position</th>
            <th>Email Address</th>
            <th>Visible</th>
            <th>&nbsp;</th>
            <th>&nbsp;</th>
          </tr>

      <?php while($exec = mysqli_fetch_assoc($exec_set)) {  ?>
       <?php $member = find_member_by_student_no($exec['student_no']); ?>
        <?php if($member['student_no'] == $_SESSION['student_no']) { ; ?>
       <!--        USER DETAILS-->
        <tr>
          <td><?php echo $exec['id']; ?></td>
          <td><?php echo $exec['student_no']; ?></td>
          <td><?php echo $member['member_name']; ?></td>
          <td><?php echo $member['member_surname']; ?></td>
          <td><?php echo $exec['exec_position']; ?></td>
          <td><?php echo $member['email_address']; ?></td>
          <td><a class="action" href="<?php echo url_for('/staff/exec/show.php?id='.h(u($exec['id']))); ?>">View</a></td>
          <td><a class="action" href="<?php echo url_for('/staff/exec/edit.php?id='.h(u($exec['id']))); ?>">Edit</a></td>
          <td><a class="action" href="<?php echo url_for('/staff/exec/delete.php?id='.h(u($exec['id']))); ?>">Delete</a></td>
    	  </tr>
        <?php } ;?>
      <!--         OTHER EXEC MEMBERS DETAISL -->
         <?php if($member['student_no']!= $_SESSION['student_no']){ ;?>
        <tr>
          <td><?php echo $exec['id']; ?></td>
          <td><?php echo $exec['student_no']; ?></td>
          <td><?php echo $member['member_name']; ?></td>
          <td><?php echo $member['member_surname']; ?></td>
          <td><?php echo $exec['exec_position']; ?></td>
          <td><?php echo $member['email_address']; ?></td>
          <td><a class="action" href="<?php echo url_for('/staff/exec/show.php?id='.h(u($exec['id']))); ?>">View</a></td>
          <td>---------</td>
          <td>---------</td>

    	  </tr>
        <?php } ?>
      <?php } ?>
  	</table>
      <?php mysqli_free_result($exec_set); ?>
  </div>

</div>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
