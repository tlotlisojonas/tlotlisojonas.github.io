<?php 
//------------------Include Initial Conditions-------------------//
require_once('../../../private/initialize.php'); 
require_login();
//----------------------Check if the form is submitted(Post Request)---------------------//

if(is_post_request()){
    
    //Initialize $exec
    $exec =[];
    
    //-------------Collect the submitted data from $_POST array into $exec array--------//
    $exec['student_no'] = $_POST['student_no']??'';
    $exec['exec_position'] = $_POST['exec_position']??'';
    $exec['password'] = $_POST['password']??'';
     $exec['confirm_password'] = $_POST['confirm_password']??'';
    $exec['reg_date'] = date('g:i a \o\n l jS F Y');
    
   //-----------Insert New data from exec array into mysql database-------------// 
    $result = insert_exec($exec);
    
    //----------------Checks if there are no errors/info is valid---------------//
    if($result===true){
        $_SESSION['message'] = "Exec member created succesfully!";
        //----------Insert a unique id to new data-----------------//
        $new_id = mysqli_insert_id($db);
        //-------------Display new data on the show page---------//
        redirect_to(url_for('/staff/exec/show.php?id='.h(u($new_id))));
    }else{
        //---------Collect errors into $error variable----------//
        $errors = $result;
    }
    
}else{
    
    //---------Display a blank form by default/when page reloads-----------------//
    $exec = [];
    $exec['student_no'] = '';
    $exec['exec_position'] = '';
    $exec['password'] ='';
    $exec['confirm_password'] ='';
}


?>


<?php $page_title = 'Add Exec Member'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">
<br>
<br>

  <a class="back-link" href="<?php echo url_for('/staff/exec/index.php'); ?>">&laquo; Back to List</a>

  <div class="subject new">
    <h1>Add New Exec Member</h1>
      </div>
<!---------------------------Display Errors If Any-------------------------->
    <?php echo display_errors($errors); ?>
      <div>
    <form action="<?php echo url_for('/staff/exec/new.php'); ?>" method="post">
      <dl>
        <dt>Student Number</dt>
        <dd><input type="text" name="student_no" value="<?php echo $exec['student_no']; ?>" /></dd>
      </dl>
      <dl>
        <dt>Exec Position</dt>
        <dd>        
        <select name="exec_position">
        <?php
          for($a=0; $a <= (count($society_positions)-1); $a++) {
            echo "<option value=\"$society_positions[$a]\"";
            if($exec["exec_position"] == $society_positions[$a]) {
              echo " selected";
            }
            echo ">$society_positions[$a]</option>";
          }
        ?>
        </select>
          </dd>
      </dl>
     <dl>
        <dt>Password</dt>
        <dd><input type="password" name="password" value="" /></dd>
      </dl>
      <dl>
        <dt>Confirm Password</dt>
        <dd><input type="password" name="confirm_password" value="" /></dd>
      </dl>
      <p>
        Passwords should be at least 12 characters and include at least one uppercase letter, lowercase letter, number, and symbol.
      </p>
      <br />
        
      <div id="operations">
        <input type="submit" value="Submit" />
      </div>
    </form>
      
  </div>

</div>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
