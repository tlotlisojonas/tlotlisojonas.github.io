<?php
require_once('../../private/initialize.php');

$errors = [];
$student_no = '';
$password = '';

if(is_post_request()) {

  $student_no = $_POST['student_no'] ?? '';
  $password = $_POST['password'] ?? '';

  // Validations
  if(is_blank($student_no)) {
    $errors[] = "Student Number cannot be blank.";
  }
  if(is_blank($password)) {
    $errors[] = "Password cannot be blank.";
  }

  // if there were no errors, try to login
  if(empty($errors)) {
    // Using one variable ensures that msg is the same
    $login_failure_msg = "Log in was unsuccessful.";

    $exec = find_exec_by_student_no($student_no);
    if($exec) {

      if(password_verify($password, $exec['hashed_password'])) {
        // password matches
        log_in_admin($exec);
        redirect_to(url_for('/staff/index.php'));
      } else {
        // student_no found, but password does not match
        $errors[] = $login_failure_msg;
      }

    } else {
      // no student_no found
      $errors[] = $login_failure_msg;
    }

  }

}

?>

<?php $page_title = 'Log in'; ?>
<?php include(SHARED_PATH . '/member_header.php'); ?>

<div id="login">
  <h1>Log in</h1>

  <?php echo display_errors($errors); ?>

  <form action="login.php" method="post">
    <strong>Student Number:</strong><br />
    <input size="30" type="text" name="student_no" value="<?php echo h($student_no); ?>" /><br />
    <strong>Password:</strong><br />
    <input  size="30" type="password" name="password" value="" /><br />
      <br>
    <input  type="submit" name="submit" value="Submit"  />
  </form>

</div>

<?php include(SHARED_PATH . '/member_footer.php'); ?>
