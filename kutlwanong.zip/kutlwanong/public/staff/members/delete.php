<?php

require_once('../../../private/initialize.php');
require_login();

//------------------Checks if there is id----------//
if(!isset($_GET['id'])){
    redirect_to(url_for('/staff/members/index.php'));
}

$id=$_GET['id'];

//-----------Checks if the delete button is pressed---------//
if(is_post_request()){
    
    $result = delete($id);
    $_SESSION['message'] = "Member deleted succesfully!";
    redirect_to(url_for('/staff/members/index.php'));
   
}else{ 
    
//--------------Default/Page reload------------//
 $member = find_by_id($id);
 
 
}
?>

<?php $page_title = 'Delete Member'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">
<br>
<br>

  <a class="back-link" href="<?php echo url_for('/staff/members/index.php'); ?>">&laquo; Back to List</a>

  <div class="subject delete">
    <h1>Delete  Member</h1>
    <p>Are you sure you want to delete </p>
     <strong><?php echo $member['member_name']." ".$member['member_surname'] ?></strong>?
    <div>
     <?php $pic_name = h($member['student_no'].'.jpg') ; ?>       

    <?php  if(file_exists('../member/images/'.$pic_name)) { ?>
          <dl>
           <dt><img  width='200px' src="../members/images/<?php echo h($member['id'].'.jpg'); ?>"></dt> 
          </dl>
    <?php }elseif($member['gender']=='Male'){  ?>
          <dl>
           <dt><img  width='200px' src="../../images/male.jpg"></dt> 
          </dl>
    <?php }else{ ?>
          <dl>
           <dt><img  width='200px' src="../../images/female.png"></dt> 
          </dl>
    <?php }; ?>      
    </div> 
    <br>
    <div>
    <form action="<?php echo url_for('/staff/members/delete.php?id=' . h(u($member['id']))); ?>" method="post">
      <div id="operations">
        <input type="submit" name="commit" value="Delete Member" />
      </div>
    </form>      
    </div>
      
  </div>

</div>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
