<?php require_once('../../../private/initialize.php');
require_login();
?>

<?php


    $member_set = find_all();



?>

<?php $page_title = 'Members'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">
  <div class="subjects listing">
    <h1>UCT Promaths Members</h1>

    <div class="actions">
      <a class="action" href="<?php echo url_for('/staff/members/new.php'); ?>">Add New Member</a>
    </div>
      <table class="list">
          <tr>
            <th>ID</th>
            <th>Student Number</th>
            <th>Name</th>
            <th>Surnmae</th>
            <th>Position</th>
            <th>Email Address</th>
            <th>&nbsp;</th>
            <th>&nbsp;</th>
            <th>&nbsp;</th>
          </tr>

      <?php while($member = mysqli_fetch_assoc($member_set)) { ?>
        <tr>
          <td><?php echo $member['id']; ?></td>
          <td><?php echo $member['student_no']; ?></td>
          <td><?php echo $member['member_name']; ?></td>
          <td><?php echo $member['member_surname']; ?></td>
          <td><?php echo $member['position']; ?></td>
          <td><?php echo $member['email_address']; ?></td>
          <td><a class="action" href="<?php echo url_for('/staff/members/show.php?id='.$member['id']); ?>">View</a></td>
          <td><a class="action" href="<?php echo url_for('/staff/members/edit.php?id='.h(u($member['id']))); ?>">Edit</a></td>
          <td><a class="action" href="<?php echo url_for('/staff/members/delete.php?id='.h(u($member['id']))); ?>">Delete</a></td>
    	  </tr>
      <?php } ?>
  	</table>
      <?php mysqli_free_result($member_set); ?>
  </div>

</div>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
