<?php
//------------------Include Initial Conditions-------------------//
require_once('../../../private/initialize.php');

//----------------------Check if the form is submitted(Post Request)---------------------//

if(is_post_request()){

    //Initialize $member
    $member =[];

    //-------------Collect the submitted data from $_POST array into $member array--------//
    $member['member_name'] = $_POST['member_name']??'';
    $member['member_surname'] = $_POST['member_surname']??'';
    $member['student_no'] = $_POST['student_no']??'';
    $member['position'] = $_POST['position']??'';
    $member['contact_no'] = $_POST['contact_no']??'';
    $member['degree_name'] = $_POST['degree_name']??'';
    $member['year_of_study'] = $_POST['year_of_study']??'';
    $member['residence'] = $_POST['residence']??'';
    $member['is_tutor'] = $_POST['is_tutor']??'';
    $member['is_mentor'] = $_POST['is_mentor']??'';
    $member['mentee_names'] = $_POST['mentee_names']??'';
    $member['mentor_name'] = $_POST['mentor_name']??'';
    $member['fuculty'] = $_POST['fuculty']??'';
    $member['bursary_name'] = $_POST['bursary_name']??'';
    $member['home_centre'] = $_POST['home_centre']??'';
    $member['gender'] = $_POST['gender']??'';

    $member['reg_date'] = date('g:i a \o\n l jS F Y');

   //-----------Insert New data from member array into mysql database-------------//
    $result = insert($member);

    //----------------Checks if there are no errors/info is valid---------------//
    if($result===true){
        $_SESSION['message'] = "New member created succesfully!";
        //----------Insert a unique id to new data-----------------//
        $new_id = mysqli_insert_id($db);
        //-------------Display new data on the show page---------//
        redirect_to(url_for('/show.php'));
    }else{
        //---------Collect errors into $error variable----------//
        $errors = $result;
    }

}else{

    //---------Display a blank form by default/when page reloads-----------------//
    $member = [];
    $member['member_name'] = '';
    $member['member_surname'] = '';
    $member['student_no'] = '';
    $member['position'] = '';
    $member['contact_no'] = '';
    $member['degree_name'] = '';
    $member['year_of_study'] = '';
    $member['residence'] = '';
    $member['fuculty'] = '';
    $member['is_tutor'] = '';
    $member['is_mentor'] = '';
    $member['mentor_name'] = '';
    $member['bursary_name'] = '';
    $member['home_centre'] = '';
    $member['gender'] = '';
}


?>


<?php $page_title = 'Add Member'; ?>
<?php include(SHARED_PATH . '/member_header.php'); ?>

<div id="new_content">
<br>
<br>

  <a class="back-link" href="<?php echo url_for('/staff/members/index.php'); ?>">&laquo; Back to List</a>

  <div class="subject new">
    <h1>Add New Member</h1>
      </div>
<!---------------------------Display Errors If Any-------------------------->
    <?php echo display_errors($errors); ?>
      <div>
    <form action="<?php echo url_for('/staff/members/new.php'); ?>" method="post">
    <div id="form_left">
      <dl>
        <dt>Member Name</dt>
        <dd><input type="text" name="member_name" value="<?php echo $member['member_name']; ?>" /></dd>
      </dl>
      <dl>
        <dt>Member Surname</dt>
        <dd><input type="text" name="member_surname" value="<?php echo $member['member_surname']; ?>" /></dd>
      </dl>
      <dl>
        <dt>Student Number</dt>
        <dd><input type="text" name="student_no" value="<?php echo $member['student_no']; ?>" /></dd>
      </dl>
      <dl>
        <dt>Contact Number</dt>
        <dd><input type="text" name="contact_no" value="<?php echo $member['contact_no']; ?>" /></dd>
      </dl>
      <dl>
        <dt>Degree Name</dt>
        <dd><input type="text" name="degree_name" value="<?php echo $member['degree_name']; ?>" /></dd>
      </dl>
      <dl>
        <dt>Bursary Name</dt>
        <dd><input type="text" name="bursary_name" value="<?php echo $member['bursary_name']; ?>" /></dd>
      </dl>
    </div>
    <div id="form_center">
      <dl>
        <dt>Fuculty</dt>
        <dd>
        <select name="fuculty">
        <?php
          for($a=0; $a <= (count($uct_fuculties)-1); $a++) {
            echo "<option value=\"$uct_fuculties[$a]\"";
            if($member["fuculty"] == $uct_fuculties[$a]) {
              echo " selected";
            }
            echo ">$uct_fuculties[$a]</option>";
          }
        ?>
        </select>
          </dd>
      </dl>
      <dl>
        <dt>Position</dt>
        <dd>
        <select name="position">
        <?php
          for($a=0; $a <= (count($society_positions)-1); $a++) {
            echo "<option value=\"$society_positions[$a]\"";
            if($member["position"] == $society_positions[$a]) {
              echo " selected";
            }
            echo ">$society_positions[$a]</option>";
          }
        ?>
        </select>
          </dd>
      </dl>
      <dl>
        <dt>Year of Study</dt>
        <dd>
        <select name="year_of_study">
        <?php
          for($a=0; $a <= (count($uct_year)-1); $a++) {
            echo "<option value=\"$uct_year[$a]\"";
            if($member["year_of_study"] == $uct_year[$a]) {
              echo " selected";
            }
            echo ">$uct_year[$a]</option>";
          }
        ?>
        </select>
          </dd>
      </dl>
      <dl>
        <dt>Are you a tutor</dt>
        <dd>
        <select name="is_tutor">
        <?php
          for($a=0; $a <= (count($yes_or_no)-1); $a++) {
            echo "<option value=\"$yes_or_no[$a]\"";
            if($member["is_tutor"] == $yes_or_no[$a]) {
              echo " selected";
            }
            echo ">$yes_or_no[$a]</option>";
          }
        ?>
        </select>
          </dd>
      </dl>
      <dl>
        <dt>Are You a Mentor</dt>
        <dd>
        <select name="is_mentor">
        <?php
          for($a=0; $a <= (count($yes_or_no)-1); $a++) {
            echo "<option value=\"$yes_or_no[$a]\"";
            if($member["is_mentor"] == $yes_or_no[$a]) {
              echo " selected";
            }
            echo ">$yes_or_no[$a]</option>";
          }
        ?>
        </select>
          </dd>
      </dl>
    </div>
    <div id="form_right">
      <dl>
        <dt>Mentor Name</dt>
        <dd>
        <select name="mentor_name">
        <?php
          for($a=0; $a <= (count($mentors)-1); $a++) {
            echo "<option value=\"$mentors[$a]\"";
            if($member["mentor_name"] == $mentors[$a]) {
              echo " selected";
            }
            echo ">$mentors[$a]</option>";
          }
        ?>
        </select>
          </dd>
      </dl>
      <dl>
        <dt>Home Centre</dt>
        <dd>
        <select name="home_centre">
        <?php
          for($a=0; $a <= (count($home_centres)-1); $a++) {
            echo "<option value=\"$home_centres[$a]\"";
            if($member["home_centre"] == $home_centres[$a]) {
              echo " selected";
            }
            echo ">$home_centres[$a]</option>";
          }
        ?>
        </select>
          </dd>
      </dl>
      <dl>
        <dt>Residence</dt>
         <dd>
          <select name="residence">
        <?php
          for($i=0; $i <= ($res_count-1); $i++) {
            echo "<option value=\"$uct_residences[$i]\"";
            if($member["residence"] == $uct_residences[$i]) {
              echo " selected";
            }
            echo ">$uct_residences[$i]</option>";
          }
        ?>
        </select>
        </dd>
      </dl>
      <dl>
        <dt>Sex</dt>
        <dd>
        <select name="gender">
        <?php
          for($a=0; $a <= (count($gender)-1); $a++) {
            echo "<option value=\"$gender[$a]\"";
            if($member["gender"] == $gender[$a]) {
              echo " selected";
            }
            echo ">$gender[$a]</option>";
          }
        ?>
        </select>
          </dd>
      </dl>
      <div id="operations_member">
        <input type="submit" value="Submit" />
      </div>
    </div>
    </form>

  </div>

</div>

<?php include(SHARED_PATH . '/member_footer.php'); ?>
