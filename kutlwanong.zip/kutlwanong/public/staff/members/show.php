<?php 

require_once('../../../private/initialize.php'); 
require_login();
$member = find_by_id(($id=$_GET['id']??'1') );
$tutor = find_tutor_by_id(($id=$_GET['id']??'1'));
?>

<?php $page_title = 'Show Member'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">
<br>
<br>

  <a class="back-link" href="<?php echo url_for('/staff/members/index.php'); ?>">&laquo; Back to List</a>

  <div class="page show">
    <h1><?php echo h($member['position']); ?></h1>
    <div class="attributes">
        
    <div class="actions">
      <a class="action" href="<?php echo url_for('/staff/members/edit.php?id=' . h(u($member['id']))); ?>">Edit</a>
      <a class="action" href="<?php echo url_for('/staff/members/delete.php?id=' . h(u($member['id']))); ?>">Delete</a>
    </div> 
        
<!---------------------------------Check if there is a picture------------------------>
        
 <?php $pic_name = h($member['student_no'].'.jpg') ; ?>       
        
<?php  if(file_exists('../../images/'.$pic_name)) { ?>
      <dl>
       <dt><img  width='200px' src="../../images/<?php echo h($member['student_no'].'.jpg'); ?>"></dt> 
      </dl>
<?php }elseif($member['gender']=='Male'){  ?>
      <dl>
       <dt><img  width='200px' src="../../images/male.jpg"></dt> 
      </dl>
<?php }else{ ?>
      <dl>
       <dt><img  width='200px' src="../../images/female.png"></dt> 
      </dl>
<?php }; ?>
        
<br>
      <dl>
          <dt>Registration Date :</dt>
          <dd><?php echo h($member['reg_date']); ?></dd>
      </dl>        
      <dl>
          <dt>Names :</dt>
          <dd><?php echo h($member['member_name']); ?></dd>
      </dl>
     <dl>
          <dt>Surname :</dt>
          <dd><?php echo h($member['member_surname']); ?></dd>
      </dl>

      <dl>
          <dt>Student Number:</dt>
          <dd><?php echo h($member['student_no']); ?></dd>
      </dl>
      <dl>
          <dt>Position:</dt>
          <dd><?php echo h($member['position']); ?></dd>
      </dl>
      <dl>
          <dt>Email Address:</dt>
          <dd><?php echo h($member['email_address']); ?></dd>
      </dl>  
      <dl>
          <dt>Contact Number:</dt>
          <dd><?php echo h($member['contact_no']); ?></dd>
      </dl>  
      <dl>
          <dt>Degree Name:</dt>
          <dd><?php echo h($member['degree_name']); ?></dd>
      </dl>
      <dl>
          <dt>Fuculty:</dt>
          <dd><?php echo h($member['fuculty']); ?></dd>
      </dl>
      <dl>
          <dt>Year of Study:</dt>
          <dd><?php echo h($member['year_of_study']); ?></dd>
      </dl>
      <dl>
          <dt>Residence:</dt>
          <dd><?php echo h($member['residence']); ?></dd>
      </dl>
      <dl>
          <dt>Tutoring:</dt>
          <dd><?php echo h($member['is_tutor']); ?></dd>
      </dl>
      <dl>
          <dt>Tutoring Courses:</dt>
          <dd><?php echo h($tutor['tutor_courses']); ?></dd>
      </dl>
      <dl>
          <dt>Mentoring:</dt>
          <dd><?php echo h($member['is_mentor']); ?></dd>
      </dl>
      <dl>
          <dt>Mentor Name:</dt>
          <dd><?php echo h($member['mentor_name']); ?></dd>
      </dl>
      <dl>
          <dt>Bursary Name:</dt>
          <dd><?php echo h($member['bursary_name']); ?></dd>
      </dl>
      <dl>
          <dt>Home Centre:</dt>
          <dd><?php echo h($member['home_centre']); ?></dd>
      </dl>
      <dl>
          <dt>Sex:</dt>
          <dd><?php echo h($member['gender']); ?></dd>
      </dl>
      </div>
  </div>
    
</div>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
