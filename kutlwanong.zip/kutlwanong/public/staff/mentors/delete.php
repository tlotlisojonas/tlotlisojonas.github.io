<?php

require_once('../../../private/initialize.php');
require_login();

//------------------Checks if there is id----------//
if(!isset($_GET['id'])){
    redirect_to(url_for('/staff/mentors/index.php'));
}

$id=$_GET['id'];

//-----------Checks if the delete button is pressed---------//
if(is_post_request()){
    
    $result = delete_mentor($id);
    $_SESSION['message'] = "Mentor deleted succesfully!";
    redirect_to(url_for('/staff/mentors/index.php'));
   
}else{ 
    
//--------------Default/Page reload------------//
$mentor = find_mentor_by_id($id);
$member = find_member_by_student_no($mentor['student_no']);
}
?>

<?php $page_title = 'Delete mentor'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">
<br>
<br>

  <a class="back-link" href="<?php echo url_for('/staff/mentors/index.php'); ?>">&laquo; Back to List</a>

  <div class="subject delete">
    <h1>Delete <?php echo $member['fuculty']; ?> mentor</h1>
    <p>Are you sure you want to delete </p>
    <?php $member = find_member_by_student_no($mentor['student_no']); ?>
     <strong><?php echo $member['member_name']." ".$member['member_surname'] ?></strong>?
    <div>
 <?php $pic_name = h($mentor['student_no'].'.jpg') ; ?>       
        
<?php  if(file_exists('../../images/'.$pic_name)) { ?>
      <dl>
       <dt><img  width='200px' src="../../images/<?php echo h($mentor['student_no'].'.jpg'); ?>"></dt> 
      </dl>
<?php }elseif($member['gender']=='Male'){  ?>
      <dl>
       <dt><img  width='200px' src="../../images/male.jpg"></dt> 
      </dl>
<?php }else{ ?>
      <dl>
       <dt><img  width='200px' src="../../images/female.png"></dt> 
      </dl>
<?php }; ?>
    </div> 
    <br>
    <div>
    <form action="<?php echo url_for('/staff/mentors/delete.php?id=' . h(u($mentor['id']))); ?>" method="post">
      <div id="operations">
        <input type="submit" name="commit" value="Delete Member" />
      </div>
    </form>      
    </div>
      
  </div>

</div>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
