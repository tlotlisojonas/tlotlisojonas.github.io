<?php 

require_once('../../../private/initialize.php'); 
require_login();


if(!isset($_GET['id'])){
    redirect_to(url_for('/staff/mentors/index.php'));
}else{

    $id = $_GET['id'];
    $mentor = find_mentor_by_id($id);
}

if(is_post_request()){
    
    //Initialize $mentor
    $mentor =[];
    
    //-------------Collect the submitted data from $_POST array into $mentor array--------//
    $mentor['id'] = $id;
    $mentor['student_no'] = $_POST['student_no']??'';
    $mentor['mentee_names'] = $_POST['mentee_names']??'';
   
    
    
    $result = update_mentor($mentor);
    
    if($result===true){
        $_SESSION['message'] = "Mentor edited succesfully!";
        redirect_to(url_for('/staff/mentors/show.php?id='.h(u($id))));
    }else{
        $errors = $result;
    }
}

?>

<?php $page_title = 'Edit mentor Details'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">
<br>
<br>

  <a class="back-link" href="<?php echo url_for('/staff/mentors/index.php'); ?>">&laquo; Back to List</a>

  <div class="subject edit">
    <h1>Edit mentor Member</h1>     
  </div>
<!---------------------------Display Errors If Any-------------------------->
    <?php echo display_errors($errors); ?>

      <div>
    <form action="<?php echo url_for('/staff/mentors/edit.php?id='.h(u($id))); ?>" method="post">
      <dl>
        <dt>Student Number</dt>
        <dd><input type="text" name="student_no" value="<?php echo $mentor['student_no']; ?>" /></dd>
      </dl>
      <dl>
        <dt>Mentee_names</dt>
        <dd><input type="text" name="mentee_names" value="<?php echo $mentor['mentee_names']; ?>" /></dd>
      </dl>
      <dl>
      <div id="operations">
        <input type="submit" value="Submit" />
      </div>
        </dl>
    </form>
          
  </div>

    
</div>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
