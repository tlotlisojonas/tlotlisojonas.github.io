<?php require_once('../../../private/initialize.php');
require_login()
 ?>

<?php


    $mentor_set = find_all_mentors();

?>

<?php $page_title = 'mentors'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">
  <div class="subjects listing">
    <h1>Promaths mentors</h1>

    <div class="actions">
      <a class="action" href="<?php echo url_for('/staff/mentors/new.php'); ?>">Add New mentor Member</a>
    </div>
      <table class="list">
          <tr>
            <th>ID</th>
            <th>Student Number</th>
            <th>Name</th>
            <th>Surnmae</th>
            <th>Fuculty</th>
            <th>Email Address</th>
            <th>&nbsp;</th>
            <th>&nbsp;</th>
            <th>&nbsp;</th>
          </tr>

      <?php while($mentor = mysqli_fetch_assoc($mentor_set)) {  ?>
       <?php $member = find_member_by_student_no($mentor['student_no']); ?>
        <tr>
          <td><?php echo $mentor['id']; ?></td>
          <td><?php echo $mentor['student_no']; ?></td>
          <td><?php echo $member['member_name']; ?></td>
          <td><?php echo $member['member_surname']; ?></td>
          <td><?php echo $member['fuculty']; ?></td>
          <td><?php echo $member['email_address']; ?></td>
          <td><a class="action" href="<?php echo url_for('/staff/mentors/show.php?id='.h(u($mentor['id']))); ?>">View</a></td>
          <td><a class="action" href="<?php echo url_for('/staff/mentors/edit.php?id='.h(u($mentor['id']))); ?>">Edit</a></td>
          <td><a class="action" href="<?php echo url_for('/staff/mentors/delete.php?id='.h(u($mentor['id']))); ?>">Delete</a></td>
    	  </tr>
      <?php } ?>
  	</table>
      <?php mysqli_free_result($mentor_set); ?>
  </div>

</div>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
