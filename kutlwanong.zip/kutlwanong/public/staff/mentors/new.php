
<?php
//------------------Include Initial Conditions-------------------//
require_once('../../../private/initialize.php');



//----------------------Check if the form is submitted(Post Request)---------------------//

if(is_post_request()){

    //Initialize $mentor
    $mentor =[];

    //-------------Collect the submitted data from $_POST array into $mentor array--------//
    $mentor['student_no'] = $_POST['student_no']??'';
    $mentor['mentee_names'] = $_POST['mentee_names']??'';
    $mentor['reg_date'] = date('g:i a \o\n l jS F Y');

   //-----------Insert New data from mentor array into mysql database-------------//
    $result = insert_mentor($mentor);

    //----------------Checks if there are no errors/info is valid---------------//
    if($result===true){
        $_SESSION['message'] = "Mentor created succesfully!";
        //----------Insert a unique id to new data-----------------//
        $new_id = mysqli_insert_id($db);
        //-------------Display new data on the show page---------//
        redirect_to(url_for('/show.php'));
    }else{
        //---------Collect errors into $error variable----------//
        $errors = $result;
    }

}else{

    //---------Display a blank form by default/when page reloads-----------------//
    $mentor = [];
    $mentor['student_no'] = '';
    $mentor['mentee_names'] = '';
}


?>


<?php $page_title = 'Add mentor'; ?>
<?php include(SHARED_PATH . '/member_header.php'); ?>

<div id="content">
<br>
<br>

  <a class="back-link" href="<?php echo url_for('/staff/mentors/index.php'); ?>">&laquo; Back to List</a>

  <div class="subject new">
    <h1>Add New mentor</h1>
      </div>
<!---------------------------Display Errors If Any-------------------------->
    <?php echo display_errors($errors); ?>
      <div>
    <form action="<?php echo url_for('/staff/mentors/new.php'); ?>" method="post">
      <dl>
        <dt>Student Number</dt>
        <dd><input type="text" name="student_no" value="<?php echo $mentor['student_no']; ?>" /></dd>
      </dl>
      <dl>
        <dt>Mentee Names</dt>
        <dd><input type="text" name="mentee_names" value="<?php echo $mentor['mentee_names']; ?>" /></dd>
      </dl>

      <div id="operations">
        <input type="submit" value="Submit" />
      </div>
    </form>

  </div>

</div>

<?php include(SHARED_PATH . '/member_footer.php'); ?>
