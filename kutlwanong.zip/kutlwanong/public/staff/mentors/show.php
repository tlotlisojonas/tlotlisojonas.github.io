<?php 

require_once('../../../private/initialize.php');
require_login();
$mentor = find_mentor_by_id(($id=$_GET['id']??'1'));
$member = find_member_by_student_no($mentor['student_no']);


?>

<?php $page_title = 'Show mentor Member'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">
<br>
<br>

  <a class="back-link" href="<?php echo url_for('/staff/mentors/index.php'); ?>">&laquo; Back to List</a>

  <div class="page show">
    <h1><?php echo h($member['fuculty'])." mentor"; ?></h1>
    <div class="attributes">
        
    <div class="actions">
      <a class="action" href="<?php echo url_for('/staff/mentors/edit.php?id=' . h(u($mentor['id']))); ?>">Edit</a>
      <a class="action" href="<?php echo url_for('/staff/mentors/delete.php?id=' . h(u($mentor['id']))); ?>">Delete</a>
    </div> 
        
<!---------------------------------Check if there is a picture------------------------>
        
 <?php $pic_name = h($mentor['student_no'].'.jpg') ; ?>       
        
<?php  if(file_exists('../../images/'.$pic_name)) { ?>
      <dl>
       <dt><img  width='200px' src="../../images/<?php echo h($mentor['student_no'].'.jpg'); ?>"></dt> 
      </dl>
<?php }elseif($member['gender']=='Male'){  ?>
      <dl>
       <dt><img  width='200px' src="../../images/male.jpg"></dt> 
      </dl>
<?php }else{ ?>
      <dl>
       <dt><img  width='200px' src="../../images/female.png"></dt> 
      </dl>
<?php }; ?>
        
<br>
      <dl>
          <dt>Registration Date :</dt>
          <dd><?php echo h($mentor['reg_date']); ?></dd>
      </dl> 
      <dl>
          <dt>Student Number:</dt>
          <dd><?php echo h($mentor['student_no']); ?></dd>
      </dl>
      <dl>
          <dt>Names :</dt>
          <dd><?php echo h($member['member_name']); ?></dd>
      </dl>
     <dl>
          <dt>Surname :</dt>
          <dd><?php echo h($member['member_surname']); ?></dd>
      </dl>
      <dl>
          <dt>Fuculty:</dt>
          <dd><?php echo h($member['fuculty']); ?></dd>
      </dl>
      <dl>
          <dt>Mentee Names:</dt>
          <dd><?php echo h($mentor['mentee_names']); ?></dd>
      </dl>    
      <dl>
          <dt>Email Address:</dt>
          <dd><?php echo h($member['email_address']); ?></dd>
      </dl>  
      <dl>
          <dt>Contact Number:</dt>
          <dd><?php echo h($member['contact_no']); ?></dd>
      </dl>  
      <dl>
          <dt>Degree Name:</dt>
          <dd><?php echo h($member['degree_name']); ?></dd>
      </dl>
      <dl>
          <dt>Year of Study:</dt>
          <dd><?php echo h($member['year_of_study']); ?></dd>
      </dl>
      <dl>
          <dt>Residence:</dt>
          <dd><?php echo h($member['residence']); ?></dd>
      </dl>
      </div>
  </div>
    
</div>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
