<?php require_once('../../../private/initialize.php');
require_login();
?>

<?php
  redirect_to(url_for('/staff/index.php'));

?>
