<?php

require_once('../../../private/initialize.php');
require_login();

//------------------Checks if there is id----------//
if(!isset($_GET['id'])){
    redirect_to(url_for('/staff/tutors/index.php'));
}

$id=$_GET['id'];

//-----------Checks if the delete button is pressed---------//
if(is_post_request()){
    
    $result = delete_tutor($id);
    $_SESSION['message'] = "Tutor deleted succesfully!";
    redirect_to(url_for('/staff/tutors/index.php'));
   
}else{ 
    
//--------------Default/Page reload------------//
$tutor = find_tutor_by_id($id);
$member = find_member_by_student_no($tutor['student_no']);
}
?>

<?php $page_title = 'Delete Tutor'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">
<br>
<br>

  <a class="back-link" href="<?php echo url_for('/staff/tutors/index.php'); ?>">&laquo; Back to List</a>

  <div class="subject delete">
    <h1>Delete <?php echo $member['fuculty']; ?> Tutor</h1>
    <p>Are you sure you want to delete </p>
    <?php $member = find_member_by_student_no($tutor['student_no']); ?>
     <strong><?php echo $member['member_name']." ".$member['member_surname'] ?></strong>?
    <div>
 <?php $pic_name = h($tutor['student_no'].'.jpg') ; ?>       
        
<?php  if(file_exists('../../images/'.$pic_name)) { ?>
      <dl>
       <dt><img  width='200px' src="../../images/<?php echo h($tutor['student_no'].'.jpg'); ?>"></dt> 
      </dl>
<?php }elseif($member['gender']=='Male'){  ?>
      <dl>
       <dt><img  width='200px' src="../../images/male.jpg"></dt> 
      </dl>
<?php }else{ ?>
      <dl>
       <dt><img  width='200px' src="../../images/female.png"></dt> 
      </dl>
<?php }; ?>
    </div> 
    <br>
    <div>
    <form action="<?php echo url_for('/staff/tutors/delete.php?id=' . h(u($tutor['id']))); ?>" method="post">
      <div id="operations">
        <input type="submit" name="commit" value="Delete Member" />
      </div>
    </form>      
    </div>
      
  </div>

</div>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
