<?php 

require_once('../../../private/initialize.php'); 
require_login();


if(!isset($_GET['id'])){
    redirect_to(url_for('/staff/tutors/index.php'));
}else{

    $id = $_GET['id'];
    $tutor = find_tutor_by_id($id);
}

if(is_post_request()){
    
    //Initialize $tutor
    $tutor =[];
    
    //-------------Collect the submitted data from $_POST array into $tutor array--------//
    $tutor['id'] = $id;
    $tutor['student_no'] = $_POST['student_no']??'';
    $tutor['tutor_courses'] = $_POST['tutor_courses']??'';
    
    
    $result = update_tutor($tutor);
    
    if($result===true){
        $_SESSION['message'] = "Tutor edited succesfully!";
        redirect_to(url_for('/staff/tutors/show.php?id='.h(u($id))));
    }else{
        $errors = $result;
    }
}

?>

<?php $page_title = 'Edit Tutor Details'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">
<br>
<br>

  <a class="back-link" href="<?php echo url_for('/staff/tutors/index.php'); ?>">&laquo; Back to List</a>

  <div class="subject edit">
    <h1>Edit tutor Member</h1>     
  </div>
<!---------------------------Display Errors If Any-------------------------->
    <?php echo display_errors($errors); ?>

      <div>
    <form action="<?php echo url_for('/staff/tutors/edit.php?id='.h(u($id))); ?>" method="post">
      <dl>
        <dt>Student Number</dt>
        <dd><input type="text" name="student_no" value="<?php echo $tutor['student_no']; ?>" /></dd>
      </dl>
      <dl>
        <dt>Courses to tutor</dt>
        <dd><input type="text" name="tutor_courses" value="<?php echo $tutor['tutor_courses']; ?>" /></dd>
      </dl>
      <div id="operations">
        <input type="submit" value="Submit" />
      </div>
    </form>
      
  </div>

    
</div>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
