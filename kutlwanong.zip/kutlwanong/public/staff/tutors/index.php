<?php require_once('../../../private/initialize.php'); ?>
require_login();
<?php


    $tutor_set = find_all_tutors();
    
?>

<?php $page_title = 'Tutors'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">
  <div class="subjects listing">
    <h1>Promaths Tutors</h1>

    <div class="actions">
      <a class="action" href="<?php echo url_for('/staff/tutors/new.php'); ?>">Add New tutor Member</a>
    </div>
      <table class="list">
          <tr>
            <th>ID</th>
            <th>Student Number</th>
            <th>Name</th>
            <th>Surnmae</th>
            <th>Fuculty</th>
            <th>Email Address</th>
            <th>&nbsp;</th>
            <th>&nbsp;</th>
            <th>&nbsp;</th>
          </tr>

      <?php while($tutor = mysqli_fetch_assoc($tutor_set)) {  ?>
       <?php $member = find_member_by_student_no($tutor['student_no']); ?>
        <tr>
          <td><?php echo $tutor['id']; ?></td>
          <td><?php echo $tutor['student_no']; ?></td>
          <td><?php echo $member['member_name']; ?></td>
          <td><?php echo $member['member_surname']; ?></td>
          <td><?php echo $member['fuculty']; ?></td>
          <td><?php echo $member['email_address']; ?></td>
          <td><a class="action" href="<?php echo url_for('/staff/tutors/show.php?id='.h(u($tutor['id']))); ?>">View</a></td>
          <td><a class="action" href="<?php echo url_for('/staff/tutors/edit.php?id='.h(u($tutor['id']))); ?>">Edit</a></td>
          <td><a class="action" href="<?php echo url_for('/staff/tutors/delete.php?id='.h(u($tutor['id']))); ?>">Delete</a></td>
    	  </tr>
      <?php } ?>
  	</table>
      <?php mysqli_free_result($tutor_set); ?>
  </div>
    
</div>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
