
<?php
//------------------Include Initial Conditions-------------------//
require_once('../../../private/initialize.php');



//----------------------Check if the form is submitted(Post Request)---------------------//

if(is_post_request()){

    //Initialize $tutor
    $tutor =[];

    //-------------Collect the submitted data from $_POST array into $tutor array--------//
    $tutor['student_no'] = $_POST['student_no']??'';
    $tutor['tutor_courses'] = $_POST['tutor_courses']??'';
    $tutor['reg_date'] = date('g:i a \o\n l jS F Y');

   //-----------Insert New data from tutor array into mysql database-------------//
    $result = insert_tutor($tutor);

    //----------------Checks if there are no errors/info is valid---------------//
    if($result===true){
        $_SESSION['message'] = "Tutor created succesfully!";
        //----------Insert a unique id to new data-----------------//
        $new_id = mysqli_insert_id($db);
        //-------------Display new data on the show page---------//
        redirect_to(url_for('/show.php'));
    }else{
        //---------Collect errors into $error variable----------//
        $errors = $result;
    }

}else{

    //---------Display a blank form by default/when page reloads-----------------//
    $tutor = [];
    $tutor['student_no'] = '';
    $tutor['tutor_courses'] = '';

}


?>


<?php $page_title = 'Add Tutor'; ?>
<?php include(SHARED_PATH . '/member_header.php'); ?>

<div id="content">
<br>
<br>

  <a class="back-link" href="<?php echo url_for('/staff/tutors/index.php'); ?>">&laquo; Back to List</a>

  <div class="subject new">
    <h1>Add New Tutor</h1>
      </div>
<!---------------------------Display Errors If Any-------------------------->
    <?php echo display_errors($errors); ?>
      <div>
    <form action="<?php echo url_for('/staff/tutors/new.php'); ?>" method="post">
      <dl>
        <dt>Student Number</dt>
        <dd><input type="text" name="student_no" value="<?php echo $tutor['student_no']; ?>" /></dd>
      </dl>
      <dl>
        <dt>Courses to tutor</dt>
        <dd><input type="text" name="tutor_courses" value="<?php echo $tutor['tutor_courses']; ?>" /></dd>
      </dl>
      <div id="operations">
        <input type="submit" value="Submit" />
      </div>
    </form>

  </div>

</div>

<?php include(SHARED_PATH . '/member_footer.php'); ?>
