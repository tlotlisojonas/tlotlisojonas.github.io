<?php 

require_once('../../../private/initialize.php');
require_login();
$tutor = find_tutor_by_id(($id=$_GET['id']??'1'));
$member = find_member_by_student_no($tutor['student_no']);


?>

<?php $page_title = 'Show tutor Member'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">
<br>
<br>

  <a class="back-link" href="<?php echo url_for('/staff/tutors/index.php'); ?>">&laquo; Back to List</a>

  <div class="page show">
    <h1><?php echo h($member['fuculty'])." Tutor"; ?></h1>
    <div class="attributes">
        
<!---------------------------------Check if there is a picture------------------------>
        
 <?php $pic_name = h($tutor['student_no'].'.jpg') ; ?>       
        
<?php  if(file_exists('../../images/'.$pic_name)) { ?>
      <dl>
       <dt><img  width='200px' src="../../images/<?php echo h($tutor['student_no'].'.jpg'); ?>"></dt> 
      </dl>
<?php }elseif($member['gender']=='Male'){  ?>
      <dl>
       <dt><img  width='200px' src="../../images/male.jpg"></dt> 
      </dl>
<?php }else{ ?>
      <dl>
       <dt><img  width='200px' src="../../images/female.png"></dt> 
      </dl>
<?php }; ?>
        
<br>
      <dl>
          <dt>Registration Date :</dt>
          <dd><?php echo h($tutor['reg_date']); ?></dd>
      </dl> 
      <dl>
          <dt>Student Number:</dt>
          <dd><?php echo h($tutor['student_no']); ?></dd>
      </dl>
      <dl>
          <dt>Names :</dt>
          <dd><?php echo h($member['member_name']); ?></dd>
      </dl>
     <dl>
          <dt>Surname :</dt>
          <dd><?php echo h($member['member_surname']); ?></dd>
      </dl>
      <dl>
          <dt>Tutor Courses:</dt>
          <dd><?php echo h($tutor['tutor_courses']); ?></dd>
      </dl>
      <dl>
          <dt>Fuculty:</dt>
          <dd><?php echo h($member['fuculty']); ?></dd>
      </dl>

      <dl>
          <dt>Email Address:</dt>
          <dd><?php echo h($member['email_address']); ?></dd>
      </dl>  
      <dl>
          <dt>Contact Number:</dt>
          <dd><?php echo h($member['contact_no']); ?></dd>
      </dl>  
      <dl>
          <dt>Degree Name:</dt>
          <dd><?php echo h($member['degree_name']); ?></dd>
      </dl>
      <dl>
          <dt>Year of Study:</dt>
          <dd><?php echo h($member['year_of_study']); ?></dd>
      </dl>
      <dl>
          <dt>Residence:</dt>
          <dd><?php echo h($member['residence']); ?></dd>
      </dl>
      <dl>
          <dt>Home Centre:</dt>
          <dd><?php echo h($member['home_centre']); ?></dd>
      </dl>
      </div>
  </div>
    
</div>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
